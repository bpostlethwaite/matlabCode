function param
% function param
% Parameters for the NLPCA.cir model run

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options zeromeanpq  n l m iter Jscale xmean xstd...
  ntrain xtrain ptrain qtrain xitrain ntest xtest ptest qtest...
  xitest MSEx ens_accept ens_MSEx ens_W ens_ptrain ens_qtrain...
  ens_xitrain ens_ptest ens_qtest ens_xitest 

%------------------------------------------------------------------
% Parameters are classified into 3 categories, '%**' means user normally
%  has to change the value to fit the problem. '%++' means user may want to
%  change the value, and '%-- means user rarely has to change the value.
 
warning off; %-- turn off warning messages
iprint = 3; %++ iprint = 0, 1, 2, 3 increases the amount of printout
isave = 1; %-- isave = 1 only saves the best sol'n in a .mat file, 
           %     plus W and MSEx of all ensemble members.
           %   isave = 2 saves all ensemble member sol'ns.
linear = 0; %-- linear = 0 for nonlinear PCA [=1 not meaningful for NLPCA.cir]
nensemble = 25; %** Number of ensemble members

testfrac = 0.15; %-- fraction of data selected as test set for early stopping
segmentlength = 1; %++ data selected in segments of length segmentlength.
overfit_tol = 0; %-- tolerance for overfitting, should be a small
                 % positive number (0.1 or less). If 0, program
                 % calculates a new overfit_tol2, and may accept
                 % some ensemble members previously rejected.
earlystop_tol = 0.1; %-- threshold for early stopping. (Not used if testfrac = 0)
xscaling = 1; %** controls scaling of x variables. -1 means no scaling.
              % 0 scales all x variables by removing the mean and
              % dividing by the standard deviation of each variable. 
              % 1 scales all x variables by removing the mean and
              % dividing by the standard deviation of the 1st x variable.
penalty = 0.1; %** scales the wt. penalty term. No penalty if set to 0.
maxiter = 1; %++  scale for the maximum number of function iterations during
             %    optimization. Start with 1, increase if needed.

%++ choose positive integer to initialize random no. generator
initRand = 1;  %++
rand('state', initRand);

initwt_radius = 1; %-- scales the radius of initial random wt. distribution

zeromeanpq = 0;  %++  [if 1, mean(p) & mean(q) forced to be zero]

% input dimensions of the networks:--------------------------------
l = 3;  %** l is the no. of x variables
m = 2;  %** m is the no. of hidden neurons in the hidden layer
%-----------------------------------------------------------------
