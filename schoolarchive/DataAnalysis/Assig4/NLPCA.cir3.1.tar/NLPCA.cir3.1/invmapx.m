function [xi,J,J0] = invmapx(p,q,x,W)
% function [xi,J,J0] = invmapx(p,q,x,W)
% Inverse map from (p,q) to xi, Computes cost function J
% (J0 is J without any penalty term).

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options zeromeanpq  n l m iter Jscale xmean xstd...
  ntrain xtrain ptrain qtrain xitrain ntest xtest ptest qtest...
  xitest MSEx ens_accept ens_MSEx ens_W ens_ptrain ens_qtrain...
  ens_xitrain ens_ptest ens_qtest ens_xitest 

[mm,nn]= size(p);
one = ones(1,nn);

ibeg = (l*m+3*m+2) + 1;
iend= ibeg -1 + m;
wp = W(ibeg:iend);
ibeg=iend+1;
iend=iend+m;
wq = W(ibeg:iend);
ibeg=iend+1;
iend=iend+m;
b = W(ibeg:iend);
ibeg=iend+1;
iend=iend+l*m;
whi = reshape(W(ibeg:iend),[l,m]);
ibeg=iend+1;
iend=iend+l;
bhi = W(ibeg:iend);

hi = zeros(m,nn);

if linear == 0 %((( nonlinear
hi = tanh(wp*p + wq*q + b*one);
else %--- linear
hi = wp*p + wq*q + b*one;
end %)))

xi = whi*hi + bhi*one;

% Compute cost function J
J0 = sum(diag((xi-x)*(xi-x)'))/nn*Jscale;  
if zeromeanpq == 1; J0 = J0 + (mean(p))^2 + (mean(q))^2; end;
J = J0;
if penalty ~= 0; J = J + penalty*norm(W(1:l*m))^2; end; % add penalty term?



