function [p,q,xi] = extracalc(xdata,W)
% function [p,q,xi] = extracalc(xdata,W)
% Performs extra calculations with NLPCA. Given xdata and W, 
% computes p,q and xi (the NLPCA approximation to xdata).
%
% Two uses for extracalc.m:
% (1) Suppose calcmode.m has been used to find the NLPCA mode for the
% dataset xdata, and now new data are available in xdatanew, then to
% get the new p,q and xi values, use  
% [p,q,xi] = extracalc(xdatanew,W);
% 
% (2) Suppose one would like to look at the solutions (p,q,xi) associated
% with ensemble member j, then use
% [p,q,xi] = extracalc(xdata,ens_W(:,:,j));

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options zeromeanpq  n l m iter Jscale xmean xstd...
  ntrain xtrain ptrain qtrain xitrain ntest xtest ptest qtest...
  xitest MSEx ens_accept ens_MSEx ens_W ens_ptrain ens_qtrain...
  ens_xitrain ens_ptest ens_qtest ens_xitest 

%%%% scales xdata  if xscaling >=0.
if xscaling >=0; %((
[xdata] = nondimen(xdata',xscaling,xmean,xstd);
xdata = xdata';
end %))

[p,q] = mappq(xdata,W);
[xi] = invmapx(p,q,xdata,W);

%%%% scale x variables if needed
if xscaling >= 0; %((
% restore xdata to original size
[xdata] = dimen(xdata',xmean,xstd,xscaling)'; 
[xi] = dimen(xi',xmean,xstd,xscaling)';
end %))
