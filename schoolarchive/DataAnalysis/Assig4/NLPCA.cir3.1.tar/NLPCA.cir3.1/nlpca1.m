% Nonlinear principal component analysis with circular bottleneck node
% (NLPCA.cir)
% Copyright (C) 2005   William W. Hsieh
%
% Extracts mode 1. Demo program. 
% Also run the linear model first.

clear all;

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options zeromeanpq  n l m iter Jscale xmean xstd...
  ntrain xtrain ptrain qtrain xitrain ntest xtest ptest qtest...
  xitest MSEx ens_accept ens_MSEx ens_W ens_ptrain ens_qtrain...
  ens_xitrain ens_ptest ens_qtest ens_xitest 

%-------------------------------------------------------------------
% load input data xdata
% x is of dimension l*n;
load data1;

cputime0 = cputime;
param  % read parameters from file param.m
%-----------------------------------------------------------------
% Uses function calcmode to calculate PCA mode 1 (linear case) 

m = 1; testfrac = 0;
fprintf(1,'\n\n###> Linear mode with hidden neurons m = %3.0f:',m);
linear = 1; 
nensemble = 5
[p,q,xi,W] = calcmode(xdata); 

% save to disc file  (tx can be left out from the save command)
save linmode1   n l m xdata tx p q xi W  linear initRand nensemble ...
  penalty  xscaling xmean xstd  ptrain qtrain xitrain MSEx ...
  ens_accept ens_MSEx ens_W 

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;
%------------------------------------------------------------------
% set number of hidden neurons to 1. 
param; % read parameters again
m = 1;
fprintf(1,'\n\n###> Nonlinear mode with number of hidden neurons m = %3.0f:\n',m);
[p,q,xi,W] = calcmode(xdata); 

% save to disc file
save mode1_m1   n l m xdata tx p q xi W  linear initRand nensemble ...
  penalty  xscaling xmean xstd ptrain qtrain ptest qtest xitrain xitest ...
  MSEx ens_accept ens_MSEx ens_W 

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;
%------------------------------------------------------------------
% set number of hidden neurons to 2.
m = 2; 
fprintf(1,'\n\n###> Nonlinear mode with number of hidden neurons m = %3.0f:\n',m);
[p,q,xi,W] = calcmode(xdata); 

% save to disc file
save mode1_m2   n l m xdata tx p q xi W  linear initRand nensemble ...
  penalty  xscaling xmean xstd ptrain qtrain ptest qtest xitrain xitest ...
  MSEx ens_accept ens_MSEx ens_W 

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;
%------------------------------------------------------------------
% set number of hidden neurons to 3
m = 3; 
fprintf(1,'\n\n###> Nonlinear mode with number of hidden neurons m = %3.0f:\n',m);
[p,q,xi,W] = calcmode(xdata); 

% save to disc file
save mode1_m3   n l m xdata tx p q xi W  linear initRand nensemble ...
  penalty  xscaling xmean xstd ptrain qtrain ptest qtest xitrain xitest ...
  MSEx ens_accept ens_MSEx ens_W 

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;
%------------------------------------------------------------------
% set number of hidden neurons to 4
m = 4; 
fprintf(1,'\n\n###> Nonlinear mode with number of hidden neurons m = %3.0f:\n',m);
[p,q,xi,W] = calcmode(xdata); 

% save to disc file
save mode1_m4   n l m xdata tx p q xi W  linear initRand nensemble ...
  penalty  xscaling xmean xstd ptrain qtrain ptest qtest xitrain xitest ...
  MSEx ens_accept ens_MSEx ens_W 

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;
