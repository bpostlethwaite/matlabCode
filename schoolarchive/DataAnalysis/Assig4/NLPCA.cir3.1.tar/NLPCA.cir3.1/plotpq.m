% Plot (p,q) for mdoes 1 and 2. Mode 2 scaled by 0.9 to avoid overlap.
clear all; clf;
load mode1
p1 = p;
q1 = q;
load mode2
axes('position',[0.2 0.2 0.6 0.7333],'AspectRatio', [1 1], ...
 'XTick', [-1 -0.5 0 0.5 1], 'YTick',[-1 -0.5 0 0.5 1]  )
plot(0.9*p,0.9*q,'o',p1,q1,'x')
xlabel('p','FontSize',16)
ylabel('q','FontSize',16)
print -deps temppq.eps
