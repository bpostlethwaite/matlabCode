function [J] = costfn(W);
% function [J] = costfn(W);
% cost function

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options zeromeanpq  n l m iter Jscale xmean xstd...
  ntrain xtrain ptrain qtrain xitrain ntest xtest ptest qtest...
  xitest MSEx ens_accept ens_MSEx ens_W ens_ptrain ens_qtrain...
  ens_xitrain ens_ptest ens_qtest ens_xitest 

[ptrain,qtrain] = mappq(xtrain,W); % forward map from x to u
[xitrain,J] = invmapx(ptrain,qtrain,xtrain,W); % inverse map from p,q to xi
iter = iter+1;




