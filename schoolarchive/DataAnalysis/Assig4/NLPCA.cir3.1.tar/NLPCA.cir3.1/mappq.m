function [p,q]  = mappq(x,W)
% function [p,q]  = mappq(x,W)
% Maps from x to p,q. 

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options zeromeanpq  n l m iter Jscale xmean xstd...
  ntrain xtrain ptrain qtrain xitrain ntest xtest ptest qtest...
  xitest MSEx ens_accept ens_MSEx ens_W ens_ptrain ens_qtrain...
  ens_xitrain ens_ptest ens_qtest ens_xitest 

[mm,nn]= size(x);
one = ones(1,nn);

iend=m*l;
wx = reshape(W(1:iend),[m,l]);
ibeg=iend+1;
iend=iend+m;
bx = W(ibeg:iend);
ibeg=iend+1;
iend=iend+m;
whp = W(ibeg:iend);
ibeg=iend+1;
iend =iend + m;
whq = W(ibeg:iend);
ibeg=iend+1;
iend =iend + 1;
bhp = W(ibeg:iend);
ibeg=iend+1;
iend =iend + 1;
bhq = W(ibeg:iend);

h = zeros(m,nn);

if linear == 0 %((( nonlinear
h = tanh(wx*x + bx*one);
else %--- linear
h = wx*x + bx*one;
end %)))

po = whp'*h + bhp*one;
qo = whq'*h + bhq*one;

r = sqrt(po.^2+qo.^2);
p = po./r;
q = qo./r;

