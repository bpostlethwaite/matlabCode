% plot output from NLPCA.cir program
clear all;
set(0,'DefaultAxesFontSize',9);

load mode1_m3 %<*** load the file you want to plot
x= xdata;

figure; % plot the x variables
subplot(2,2,1);
plot(x(1,:),x(2,:),'.',xi(1,:),xi(2,:),'o','Markersize',4)

title('(a)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{2}','FontSize',12)

subplot(2,2,2);
plot(x(1,:),x(3,:),'.',xi(1,:),xi(3,:),'o','Markersize',4)

title('(b)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{3}','FontSize',12)

subplot(2,2,3);
plot(x(2,:),x(3,:),'.',xi(2,:),xi(3,:),'o','Markersize',4)
title('(c)','FontSize',13)
xlabel('x_{2}','FontSize',12)
ylabel('x_{3}','FontSize',12)

subplot(2,2,4);
plot3(xi(1,:),xi(2,:),xi(3,:),'o','Markersize',4);

view([-32.5,40]);  %<<<<< vary view angles for different 3D perspective

title('(d)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{2}','FontSize',12)
zlabel('x_{3}','FontSize',12)
box off; grid on;

print -deps temp1x.eps

