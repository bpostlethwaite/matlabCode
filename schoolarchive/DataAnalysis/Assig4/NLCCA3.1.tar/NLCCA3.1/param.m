function param
% function param
% Parameters for the NLCCA model run

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol scaling penalty maxiter initRand ...
  initwt_radius options n l1 m1 l2 m2 iter xmean xstd ymean ystd...
  ntrain xtrain ytrain utrain vtrain xitrain yitrain ...
  ntest xtest ytest utest vtest xitest yitest corruv MSEx MSEy ...
  ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy ...
  ens_W ens_W1 ens_W2 ens_utrain ens_vtrain ens_xitrain ens_yitrain ...
  ens_utest ens_vtest ens_xitest ens_yitest 

%------------------------------------------------------------------

warning off; % turn off warning messages
iprint = 3; %++ iprint = 0, 1, 2, 3 increases the amount of printout
isave = 1; %-- isave = 1 only saves the best sol'n in a .mat file, 
           %    & W, W1, W2, corruv, MSEx, MSEy of all ensemble members.
           %   isave = 2 saves all ensemble member sol'ns.
linear = 0; %-- linear = 0 for nonlinear CCA, 1 for linear CCA.
nensemble = 30; %** Number of ensemble members

testfrac = 0.15; %-- fraction of data selected as test set for early stopping
segmentlength = 1; %++ data selected in segments of length segmentlength.
overfit_tol = 0; %-- tolerance for overfitting, should be a small
                 % positive number (0.1 or less). If 0, program
                 % calculates a new overfit_tol2, and may accept
                 % some ensemble members previously rejected.
earlystop_tol = 0.1; %-- threshold for early stopping. (Not used if testfrac = 0)
scaling = 1; %** specifies the scaling for x and y variables.
                 % scaling(1) =  -1 means no scaling on the x variables.
                 % 0 scales all x variables by removing the mean and
                 % dividing by the standard deviation of each variable. 
                 % 1 scales all x variables by removing the mean and
                 % dividing by the standard deviation of the 1st x variable.
                 % Similary for the y variable, as controlled by
                 % scaling(2) [which defaults to scaling(1)].
penalty = 0.01; %** scales the wt. penalty term. No penalty if set to 0.
maxiter = 1; %++  scale for the maximum number of function iterations during
             %    optimization. Start with 1, increase if needed.

%++ choose positive integer to initialize random no. generator
initRand = 1;  %++
rand('state', initRand);

initwt_radius = 1; %-- scales the radius of initial random wt. distribution

% input dimensions of the networks:--------------------------------
l1 = 3;  %** l1 is the no. of x variables
m1 = 3;  %** m1 is the no. of y variables

l2 = 2; %** l2 is the no. of hidden neurons after the l1 x-variables
m2 = 2;  %** m2 is the no. of hidden neurons after the m1 y-variables
%-----------------------------------------------------------------
