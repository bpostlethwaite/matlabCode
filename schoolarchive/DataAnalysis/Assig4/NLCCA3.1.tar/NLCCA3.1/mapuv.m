function [u,v,J]  = mapuv(x,y,W)
% function [u,v,J]  = mapuv(x,y,W)
% Maps from (x,y) to (u,v). Calculates the cost function J

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol scaling penalty maxiter initRand ...
  initwt_radius options n l1 m1 l2 m2 iter xmean xstd ymean ystd...
  ntrain xtrain ytrain utrain vtrain xitrain yitrain ...
  ntest xtest ytest utest vtest xitest yitest corruv MSEx MSEy ...
  ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy ...
  ens_W ens_W1 ens_W2 ens_utrain ens_vtrain ens_xitrain ens_yitrain ...
  ens_utest ens_vtest ens_xitest ens_yitest 

[m,nn]= size(x);
one = ones(1,nn);

iend=l2*l1;
wx = reshape(W(1:iend),[l2,l1]);
ibeg=iend+1;
iend=iend+l2;
bx = W(ibeg:iend);
ibeg=iend+1;
iend=iend+m2*m1;
wy = reshape(W(ibeg:iend),[m2,m1]);
ibeg=iend+1;
iend=iend+m2;
by = W(ibeg:iend);
ibeg=iend+1;
iend=iend+l2;
whx = W(ibeg:iend);
ibeg=iend+1;
iend=iend+m2;
why = W(ibeg:iend);
bhx = W(iend+1); bhy = W(iend+2);

hx = zeros(l2,nn);
hy = zeros(m2,nn);

if linear == 0 %((( nonlinear
hx = tanh(wx*x + bx*one);
hy = tanh(wy*y + by*one);
else %--- linear
hx = wx*x + bx*one;
hy = wy*y + by*one;
end %)))

u = whx'*hx + bhx*one;
v = why'*hy + bhy*one;

% Calculate cost function J  
sqrtmeanu2 = sqrt(u*u'/nn);
sqrtmeanv2 = sqrt(v*v'/nn);
J = -u*v'/nn/(sqrtmeanu2*sqrtmeanv2) ...
    + (sqrtmeanu2 - 1)^2 + (sqrtmeanv2 - 1)^2 ...
    + (mean(u))^2 + (mean(v))^2 ;
if penalty(1) ~= 0; % add penalty term?
  wxend = l2*l1;  wybeg = wxend + l2 +1; wyend = wybeg + m2*m1;
  J = J + penalty(1)*(norm(W(1:wxend))^2 + norm(W(wybeg:wyend))^2); 
end; 

