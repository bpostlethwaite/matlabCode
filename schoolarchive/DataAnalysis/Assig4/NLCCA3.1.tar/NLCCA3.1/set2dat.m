% setup data1.mat for NLCCA test problem
% produces postscript files tempx.ps & tempy.ps for the x & y data respectively
clear all;
n = 500 % generate 500 samples

rand('state',0); % initialize uniform random no. generator
randn('state',0); % initialize normal distr. random no. generator
x = zeros(3,n);
y = zeros(3,n);
x1 = zeros(3,n);
y1 = zeros(3,n);
x2 = zeros(3,n);
y2 = zeros(3,n);
t = 2*rand(1,n)-1.; % random number converted to lie in the interval (-1,1)
s = 2*rand(1,n)-1.; % random number converted to lie in the interval (-1,1)
 
% mode 1 variables
x1(1,:) = t-0.3*t.^2;
x1(2,:) = t+0.3*t.^3;
x1(3,:) = t.^2; 
x1 =nondimen(x1')';
  
y1(1,:) = t.^3;
y1(2,:) = -t + 0.3*t.^3;
y1(3,:) = t+0.3*t.^2;

y1=nondimen(y1')';

% generate mode 1 for plotting
mx1 = zeros(3,41);
my1 = zeros(3,41);

tt = [-1:0.05:1];
mx1(1,:) = tt-0.3*tt.^2;
mx1(2,:) = tt+0.3*tt.^3;
mx1(3,:) = tt.^2;
 
my1(1,:) = tt.^3;
my1(2,:) = -tt + 0.3*tt.^3;
my1(3,:) = tt+0.3*tt.^2;


mx1 =nondimen(mx1')';
my1 =nondimen(my1')'; 
 
% mode 2 variables
x2(1,:) =  -s-0.3*s.^2;
x2(2,:) =  s-0.3*s.^3;
x2(3,:) =  -s.^4;

x2 =nondimen(x2')';

y2(1,:) =  sech(4*s);
y2(2,:) =  s+0.3*s.^3;
y2(3,:) =  s-0.3*s.^2;

y2=nondimen(y2')' ;

% generate mode 2 for plotting
mx2 = zeros(3,41);
my2 = zeros(3,41);

ss =[-1:0.05:1];
 
mx2(1,:) =  -ss-0.3*ss.^2;
mx2(2,:) =  ss-0.3*ss.^3;
mx2(3,:) = -ss.^4;

my2(1,:) =  sech(4*ss);
my2(2,:) =  ss+0.3*ss.^3;
my2(3,:) =  ss-0.3*ss.^2;

mx2 =nondimen(mx2')';
my2 =nondimen(my2')';

% add mode 1 and mode 2 contributions
x2 = 0.577*x2; % scale mode 2 to have only 1/3 the variance of mode 1
y2 = 0.577*y2;
mx2 = 0.577*mx2;
my2 = 0.577*my2;
x = x1 + x2;
y = y1 + y2;
x = nondimen(x')';
y = nondimen(y')';
x = x+0.1*randn(3,n); % add 10% Gaussian noise
y = y+0.1*randn(3,n);
x = nondimen(x')';
y = nondimen(y')';

% rename and save data onto a file data1.mat
xdata = x; ydata = y; tx = t; ty = s;
save data1 xdata ydata tx ty mx1 my1 mx2 my2;

% plot x variables ------------------------------------------------
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultAxesFontSize',9);
figure;
subplot(2,2,1);
plot(x(1,:),x(2,:),'.',mx1(1,:),mx1(2,:),'o',mx2(1,:),mx2(2,:),'-','MarkerSize',4);
title('(a)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{2}','FontSize',12)

subplot(2,2,2);
plot(x(1,:),x(3,:),'.',mx1(1,:),mx1(3,:),'o',mx2(1,:),mx2(3,:),'-','MarkerSize',4);
title('(b)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{3}','FontSize',12)

subplot(2,2,3);
plot(x(2,:),x(3,:),'.',mx1(2,:),mx1(3,:),'o',mx2(2,:),mx2(3,:),'-','MarkerSize',4);
title('(c)','FontSize',13)
xlabel('x_{2}','FontSize',12)
ylabel('x_{3}','FontSize',12)

subplot(2,2,4);
plot3(mx1(1,:),mx1(2,:),mx1(3,:),'o',mx2(1,:),mx2(2,:),mx2(3,:),'-','MarkerSize',4);
title('(d)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{2}','FontSize',12)
zlabel('x_{3}','FontSize',12)
print -dps tempx.ps

% plot y variables
figure;
subplot(2,2,1);
plot(y(1,:),y(2,:),'.',my1(1,:),my1(2,:),'o',my2(1,:),my2(2,:),'-','MarkerSize',4);
title('(a)','FontSize',13);
xlabel('y_{1}','FontSize',12);
ylabel('y_{2}','FontSize',12);

subplot(2,2,2);
plot(y(1,:),y(3,:),'.',my1(1,:),my1(3,:),'o',my2(1,:),my2(3,:),'-','MarkerSize',4);
title('(b)','FontSize',13);
xlabel('y_{1}','FontSize',12);
ylabel('y_{3}','FontSize',12);

subplot(2,2,3);
plot(y(2,:),y(3,:),'.',my1(2,:),my1(3,:),'o',my2(2,:),my2(3,:),'-','MarkerSize',4);
title('(c)','FontSize',13);
xlabel('y_{2}','FontSize',12);
ylabel('y_{3}','FontSize',12);

subplot(2,2,4);
plot3(my1(1,:),my1(2,:),my1(3,:),'o',my2(1,:),my2(2,:),my2(3,:),'-','MarkerSize',4);
title('(d)','FontSize',13);
xlabel('y_{1}','FontSize',12);
ylabel('y_{2}','FontSize',12);
zlabel('y_{3}','FontSize',12);
print -dps tempy.ps


