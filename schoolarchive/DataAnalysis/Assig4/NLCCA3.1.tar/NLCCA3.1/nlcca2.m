% Nonlinear canonical correlation analysis (NLCCA) program by W.Hsieh.
% Extracts mode 2.  Demo program
clear all;

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol scaling penalty maxiter initRand ...
  initwt_radius options n l1 m1 l2 m2 iter xmean xstd ymean ystd...
  ntrain xtrain ytrain utrain vtrain xitrain yitrain ...
  ntest xtest ytest utest vtest xitest yitest corruv MSEx MSEy ...
  ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy ...
  ens_W ens_W1 ens_W2 ens_utrain ens_vtrain ens_xitrain ens_yitrain ...
  ens_utest ens_vtest ens_xitest ens_yitest

%------------------------------------------------------------------
% Uses function calcmode to calculate CCA mode 2 (linear case)
load linmode1_h1; % load from linmode1_h1
%  remove contributions from mode 1.
xdata = xdata - xi;
ydata = ydata - yi;

cputime0 = cputime;
param;
 
linear = 1; nensemble = 5; l2 = 1; m2 = 1; testfrac = 0;
fprintf(1,'\n\n### Linear Run with no. of hidden neurons l2 = %3.0f, m2 = %3.0f:'...
,l2,m2);
[u,v,xi,yi,W,W1,W2] = calcmode(xdata,ydata); 

% save to disc file  (tx and ty can be omitted from the save command)
save linmode2_h1   n l1 m1 l2 m2 xdata ydata tx ty u v xi yi ...
    W W1 W2 linear scaling penalty initRand nensemble xmean xstd ymean ystd...
    utrain  vtrain  xitrain  yitrain MSEx MSEy corruv ...
    ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy


fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;
%-------------------------------------------------------------------
% load input data xdata and ydata
% x is of dimension l1*n; y is of dimension m1*n.
load mode1_h3; %<<<<<< load mode 1 file <<<<<<<<<<<<<<<<<<<<<<<
%  remove contributions from mode 1.
xdata = xdata - xi;
ydata = ydata - yi;

param  % load parameters from file param.m
%---------------------------------------------------------------------
% set number of hidden neurons to 2
l2 = 2; m2 = 2;
fprintf(1,'\n\n###>> Run with no. of hidden neurons l2 = %3.0f, m2 = %3.0f:'...
,l2,m2);
[u,v,xi,yi,W,W1,W2] = calcmode(xdata,ydata); 

% save to disc file
save mode2_h2   n l1 m1 l2 m2 xdata ydata tx ty u v xi yi ...
    W W1 W2 linear scaling penalty initRand nensemble xmean xstd ymean ystd...
    utrain  vtrain  xitrain  yitrain MSEx MSEy corruv ...
    ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;
%------------------------------------------------------------------
% set number of hidden neurons to 3
l2 = 3; m2 = 3;
fprintf(1,'\n\n###>> Run with no. of hidden neurons l2 = %3.0f, m2 = %3.0f:'...
,l2,m2);
[u,v,xi,yi,W,W1,W2] = calcmode(xdata,ydata); 

% save to disc file
save mode2_h3   n l1 m1 l2 m2 xdata ydata tx ty u v xi yi ...
    W W1 W2 linear scaling penalty initRand nensemble xmean xstd ymean ystd...
    utrain  vtrain  xitrain  yitrain MSEx MSEy corruv ...
    ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy


fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;

