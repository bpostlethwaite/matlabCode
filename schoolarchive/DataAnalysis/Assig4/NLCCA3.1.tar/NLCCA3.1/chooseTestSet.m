function [n,xtrain,ytrain,ntrain,xtest,ytest,ntest,testsetindex] = ...
                    chooseTestSet(xdata,ydata,testfrac,segmentlength,iprint);
% function [n,xtrain,ytrain,ntrain,xtest,ytest,ntest,testsetindex] = ...
%                   chooseTestSet(xdata,ydata,testfrac,segmentlength,iprint);
% From the original pairs (xdata,ydata), randomly choose testfrac
% fraction as test data (xtest,ytest), and the remainder as training
% data (xtrain,ytrain). testsetindex = 0 if the original sample is
% selected to be in the training set, and 1 if in the test set.
%   If segmentlength is set to integer values greater than 1, then
% the test data will be selected in segments of length 'segmentlength',
% to account for the autocorrelation in the data.
% Set segmentlength = 1 if autocorrelation is not a problem.

%-initRand = 1; % choose positive integer to initialize random no. generator
%-rand('state', initRand); % initialize random number generator
[mx,n] = size(xdata);  % n is the number of samples
nx = n;
segment = round(segmentlength);
nsegments = floor(n/segment);
testsegmentindex = zeros(1,nsegments); 
testsetindex = zeros(1,n);
ntestselected = 0;
ntest = round(n*testfrac/segment)*segment;

% Select test data
while ntestselected < ntest; %[[[[[
location = round(1+(nsegments-1)*rand);
if testsegmentindex(1,location) ~=1,  %(((( 
 testsegmentindex(1,location) = 1;
 testsetindex(1,(location-1)*segment+1:location*segment) = 1;
 ntestselected = ntestselected + segment;
end %))))
end %]]]]]

ntrain = n - ntest;
xtest = zeros(mx,ntest);
[my,n] = size(ydata);
% check that the sample size for x and y are equal. If not, stop
if n ~= nx; error('x and y have different no. of samples.'); end;
ytest = zeros(my,ntest);
xtrain = zeros(mx,ntrain);
ytrain = zeros(my,ntrain);

itest=1;
itrain=1;
for i=1:n %[[[[[[
if testsetindex(1,i) == 1
xtest(:,itest) = xdata(:,i);
ytest(:,itest) = ydata(:,i);
itest = itest + 1;
else
xtrain(:,itrain) = xdata(:,i);
ytrain(:,itrain) = ydata(:,i);
itrain = itrain + 1;
end
end %]]]]]]

if iprint > 0;
fprintf(1,'\nn =%6.0f,  ntrain =%6.0f,  ntest = %6.0f,  testfrac =%6.3f\n',...
  n,ntrain,ntest,testfrac);
end;
