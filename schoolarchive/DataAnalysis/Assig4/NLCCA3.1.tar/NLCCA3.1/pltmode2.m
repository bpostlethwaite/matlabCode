% plot mode 2 from NLCCA program
% produces (encapsuled) postscript files temp2.eps
% Ignore temporary figure plotted before the final figure.
clear all;

load linmode2_h1 % load linear CCA mode 1
xlin = xi; ylin = yi;
% locate the end coordinates of the line described by the linear mode.
[xl(1,1),imax] = max(xlin(1,:)); [xl(1,2),imin] = min(xlin(1,:));
xl(2,1) = xlin(2,imax); xl(2,2) = xlin(2,imin);
xl(3,1) = xlin(3,imax); xl(3,2) = xlin(3,imin);
[yl(1,1),jmax] = max(ylin(1,:)); [yl(1,2),jmin] = min(ylin(1,:));
yl(2,1) = ylin(2,jmax); yl(2,2) = ylin(2,jmin);
yl(3,1) = ylin(3,jmax); yl(3,2) = ylin(3,jmin);


load mode2_h3; %<<<<<<  load file containing the NLCCA mode 1
x = xdata;  y = ydata;

set(0,'DefaultFigurePaperOrientation','landscape')
set(gcf,'PaperPosition',[0.25  1.75  10.5  5.]);

% first x plot is discarded
figure;
subplot(1,2,1)
plot3(x(1,:),x(2,:),x(3,:),'.',xi(1,:),xi(2,:),xi(3,:),'square',...
xl(1,:),xl(2,:),xl(3,:),'--');
title('(a)','FontSize',14)
xl1=get(gca,'XLim'); x01=max(xl1); 
xl2=get(gca,'YLim'); x02=max(xl2);
xl3=get(gca,'ZLim'); x03=min(xl3);
x0l1 = x01*ones(1,size(xl,2)); x01 = x01*ones(1,size(xi,2)); 
x0l2 = x02*ones(1,size(xl,2)); x02 = x02*ones(1,size(xi,2)); 
x0l3 = x03*ones(1,size(xl,2)); x03 = x03*ones(1,size(xi,2));
 
% first y plot is discarded
subplot(1,2,2);
plot3(y(1,:),y(2,:),y(3,:),'.',yi(1,:),yi(2,:),yi(3,:),'square',...
yl(1,:),yl(2,:),yl(3,:),'--');
title('(b)','FontSize',14)
yl1= get(gca,'XLim'); y01=max(yl1); 
yl2= get(gca,'YLim'); y02=max(yl2);
yl3= get(gca,'ZLim'); y03=min(yl3);
y0l1 = y01*ones(1,size(yl,2)); y01 = y01*ones(1,size(yi,2)); 
y0l2 = y02*ones(1,size(yl,2)); y02 = y02*ones(1,size(yi,2)); 
y0l3 = y03*ones(1,size(yl,2)); y03 = y03*ones(1,size(yi,2));

%------ begin the desired plot of x and y variables ----------------
figure;
set(gcf,'PaperPosition',[0.25  1.75  10.5  5.]);
h = axes('GridLineStyle','--','FontSize',11);

subplot(1,2,1); % this is the desired plot for the x variables

plot3(xl(1,:),xl(2,:),xl(3,:),'--',xi(1,:),xi(2,:),xi(3,:),'square',...
xl(1,:),xl(2,:),x0l3,'-',x(1,:),x(2,:),x03,'.',xi(1,:),xi(2,:),x03,'o',...
xl(1,:),x0l2,xl(3,:),'-',x(1,:),x02,x(3,:),'.',xi(1,:),x02,xi(3,:),'o',...
x0l1,xl(2,:),xl(3,:),'-',x01,x(2,:),x(3,:),'.',x01,xi(2,:),xi(3,:),'o',...
'Markersize',4);

set(gca,'XLim',xl1,'YLim',xl2,'ZLim',xl3,...
'XLimmode','manual','YLimmode','manual','ZLimmode','manual');

view([-32.5,40]); %<<<<< vary view angles for different 3D perspective

title('(a)','FontSize',14)
xlabel('x_{1}','FontSize',13)
ylabel('x_{2}','FontSize',13)
zlabel('x_{3}','FontSize',13)
box off; grid on;
 
subplot(1,2,2); % this is the desired plot for the y variables

plot3(yl(1,:),yl(2,:),yl(3,:),'--',yi(1,:),yi(2,:),yi(3,:),'square',...
yl(1,:),yl(2,:),y0l3,'-',y(1,:),y(2,:),y03,'.',yi(1,:),yi(2,:),y03,'o',...
yl(1,:),y0l2,yl(3,:),'-',y(1,:),y02,y(3,:),'.',yi(1,:),y02,yi(3,:),'o',...
y0l1,yl(2,:),yl(3,:),'-',y01,y(2,:),y(3,:),'.',y01,yi(2,:),yi(3,:),'o',...
'Markersize',4);

set(gca,'XLim',yl1,'YLim',yl2,'ZLim',yl3,...
'XLimmode','manual','YLimmode','manual','ZLimmode','manual');

view([-32.5,40]); %<<<<< vary view angles for different 3D perspective

title('(b)','FontSize',14)
xlabel('y_{1}','FontSize',13)
ylabel('y_{2}','FontSize',13)
zlabel('y_{3}','FontSize',13)
box off; grid on;

print -deps temp2.eps
