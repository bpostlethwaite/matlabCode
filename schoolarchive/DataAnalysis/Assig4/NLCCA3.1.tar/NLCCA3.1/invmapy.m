function [yi,J2,MSEy] = invmapy(v,y,W2)
% function [yi,J2,MSEy] = invmapy(v,y,W2)
% Inverse map from v to yi. Calculates the cost function J2, & MSEy.

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol scaling penalty maxiter initRand ...
  initwt_radius options n l1 m1 l2 m2 iter xmean xstd ymean ystd...
  ntrain xtrain ytrain utrain vtrain xitrain yitrain ...
  ntest xtest ytest utest vtest xitest yitest corruv MSEx MSEy ...
  ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy ...
  ens_W ens_W1 ens_W2 ens_utrain ens_vtrain ens_xitrain ens_yitrain ...
  ens_utest ens_vtest ens_xitest ens_yitest 

[m,nn]= size(v);
one = ones(1,nn);

iend=m2;
wv = W2(1:iend);
ibeg=iend+1;
iend=iend+m2;
bv = W2(ibeg:iend);
ibeg=iend+1;
iend=iend+m2*m1;
whv = reshape(W2(ibeg:iend),[m1,m2]);
ibeg=iend+1;
iend=iend+m1;
bhv = W2(ibeg:iend);

hv = zeros(m2,nn);

if linear == 0; %((( nonlinear
hv = tanh(wv*v + bv*one);
else %--- linear
hv = wv*v + bv*one;
end %)))

yi = whv*hv + bhv*one;

MSEy = sum(diag((yi-y)*(yi-y)'))/nn;  
J2 = MSEy;
% add penalty term?
if penalty(3) ~= 0; J2 = J2 + penalty(3)*norm(W2(1:m2))^2; end; 
