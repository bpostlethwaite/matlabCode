function [xi,J1,MSEx] = invmapx(u,x,W1)
% function [xi,J1,MSEx] = invmapx(u,x,W1)
% Inverse map from u to xi. Calcualtes the cost function J1, and MSEx.

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol scaling penalty maxiter initRand ...
  initwt_radius options n l1 m1 l2 m2 iter xmean xstd ymean ystd...
  ntrain xtrain ytrain utrain vtrain xitrain yitrain ...
  ntest xtest ytest utest vtest xitest yitest corruv MSEx MSEy ...
  ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy ...
  ens_W ens_W1 ens_W2 ens_utrain ens_vtrain ens_xitrain ens_yitrain ...
  ens_utest ens_vtest ens_xitest ens_yitest 

[m,nn]= size(u);
one = ones(1,nn);

iend=l2;
wu = W1(1:iend);
ibeg=iend+1;
iend=iend+l2;
bu = W1(ibeg:iend);
ibeg=iend+1;
iend=iend+l2*l1;
whu = reshape(W1(ibeg:iend),[l1,l2]);
ibeg=iend+1;
iend=iend+l1;
bhu = W1(ibeg:iend);

hu = zeros(l2,nn);

if linear == 0 %((( nonlinear
hu = tanh(wu*u + bu*one);
else %--- linear
hu = wu*u + bu*one;
end %)))

xi = whu*hu + bhu*one;

MSEx = sum(diag((xi-x)*(xi-x)'))/nn; 
J1 = MSEx;
% add penalty term?
if penalty(2) ~= 0; J1 = J1 + penalty(2)*norm(W1(1:l2))^2; end; 
