function [uvtrain,uvtest] =  chooseTestuv(uv,testsetindex);
% function [uvtrain,uvtest] =  chooseTestuv(uv,testsetindex);
% Since testsetindex = 0 if the original sample is selected to be
% in the training set, and 1 if in the test set, this info
% is used to select uvtrain and uvtest from the original set uv.

[mx,nx] = size(uv);  % nx is the number of samples

ntrain = 0;
ntest = 0;

for i = 1:nx
if testsetindex(i) == 0;
ntrain = ntrain +1;
uvtrain(ntrain)= uv(i);
else
ntest = ntest+1;
uvtest(ntest) = uv(i);
end
end

