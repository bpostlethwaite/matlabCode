function [u,v,xi,yi,W,W1,W2] = calcmode(xdata,ydata)
% function [u,v,xi,yi,W,W1,W2] = calcmode(xdata,ydata)
% Copyright (C) 2001   William W. Hsieh
% Calculates 1 NLCCA  mode.
% Some adjustable parameters are indicated by %>>>>.

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol scaling penalty maxiter initRand ...
  initwt_radius options n l1 m1 l2 m2 iter xmean xstd ymean ystd...
  ntrain xtrain ytrain utrain vtrain xitrain yitrain ...
  ntest xtest ytest utest vtest xitest yitest corruv MSEx MSEy ...
  ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy ...
  ens_W ens_W1 ens_W2 ens_utrain ens_vtrain ens_xitrain ens_yitrain ...
  ens_utest ens_vtest ens_xitest ens_yitest 

% For more info on the options in the optimization m-file fminu, 
% type: help foptions
options(1) = -1;     %  no printout from fminu. 
%>>>> termination criterion for weights in the optimization
options(2) = 1.e-4;  %>>>>
%>>>> termination criterion for cost functions J, J1 & J2
options(3) = 1.e-4;  %>>>>

% set default parameters?
printskip = 4; %>>>> 1 => prints every line; 4 => every 4th line
if size(scaling,2) == 1; scaling(2) = scaling(1); end;
if size(penalty,2) == 1; 
  penalty(2) = penalty(1); penalty(3) = penalty(1); end;
if size(maxiter,2) == 1; 
  maxiter(2) = maxiter(1); maxiter(3) = maxiter(1); end;
if size(initwt_radius,2) == 1;
 initwt_radius(2)=initwt_radius(1); initwt_radius(3)=initwt_radius(1);
end;

%%%% scales xdata  if scaling(1) >=0.
if scaling(1) >=0; %((
[xdata,xmean,xstd] = nondimen(xdata',scaling(1));
xdata = xdata';
end %))
%%%% scales ydata  if scaling(2) >=0.
if scaling(2) >=0; %((
[ydata,ymean,ystd] = nondimen(ydata',scaling(2));
ydata = ydata';
end %))

if iprint > 0;
  if linear == 0; fprintf(1,'\nNLCCA nonlinear mode:\n'); end;
  if linear == 1; fprintf(1,'\nNLCCA linear mode:\n'); end;
  if penalty*penalty'>0;
    fprintf(1,'\n penalty = [%9.4g %9.4g %9.4g ]\n',penalty);
  end;
end;

%%%% Set the factor to expand random wt. radius between ensemble members.
overallexpand = 4; %>>>> wt. radii expand by this overall factor between
                   % the 1st ensemble member and the last.
expand = overallexpand^(1./nensemble); % wt. expand factor between
                                      % adjacent ensemble members.

%================= forward mapping NN (x,y -> u,v) =========================
%%%% Initialize variables
Jtest = 0; corruvtest = 0; correns= -1; ens_accept = zeros(1,nensemble);
ens_corruv = zeros(1,nensemble); ens_delcorruv = zeros(1,nensemble);
if iprint>=2; fprintf(1,'\n## Forward mapping problem (x,y) to (u,v):\n');end;

for iensemble = 1: nensemble %{{{{{{ ensemble ----------------------------

% The records xdata and ydata are randomly divided into training
% pairs (xtrain,ytrain) and testing pairs (xtest,ytest). 
% testfrac is the fraction selected for testing.
[n,xtrain,ytrain,ntrain,xtest,ytest,ntest,testsetindex] = ...
                    chooseTestSet(xdata,ydata,testfrac,segmentlength,0);

if iprint >=2; fprintf(1,'\nEnsemble member no.%4.0f ',iensemble); end;

%%%% setup various matrices in the forward mapping

wx = zeros(l2,l1);
bx = zeros(l2,1);
wy = zeros(m2,m1);
by = zeros(m2,1);
whx = zeros(l2,1);
why = zeros(m2,1);
bhx = 0; bhy = 0;
utrain = zeros(1,ntrain);
vtrain = zeros(1,ntrain);

% combine all the weight and bias parameters into a single W vector
W = [reshape(wx,[l2*l1,1]);bx;reshape(wy,[m2*m1,1]);by;whx;why;bhx;bhy]; 

if iensemble == 1; %[[[ set up matrices
ens_W = zeros(size(W,1),size(W,2),nensemble);
if isave >= 2 %(( 
ens_utrain = zeros(1,ntrain,nensemble); 
ens_vtrain = zeros(1,ntrain,nensemble);
ens_xitrain = zeros(l,ntrain,nensemble);
ens_yitrain = zeros(l,ntrain,nensemble);
ens_utest = zeros(1,ntest,nensemble);
ens_vtest = zeros(1,ntest,nensemble); 
ens_xitest = zeros(l,ntest,nensemble);
ens_yitest = zeros(l,ntest,nensemble);
end; %))
end %]]]

% random initial weights.
radius=initwt_radius(1)*0.25*sqrt(size(xtrain,1)*size(xtrain,2))/norm(xtrain);
W = (expand^iensemble)*radius*(2.*rand(size(W))-1.) ;

%%%% find the optimal solution for the forward mapping problem
%>>>> max. no. of function iterations.
maxiterations= maxiter(1)*300*max(size(W)); 

%>>>> no. of iterations before checking for early stopping
niterchk = round(maxiterations/20);

options(14)= niterchk; maxloop = round(maxiterations/niterchk);
iter=0; corruvold = -1; corruvtestold = -1; corruvtrainprev = -1;

% print results prior to training
[utrain,vtrain,Jtrain] = mapuv(xtrain,ytrain,W); % training data
corr = corrcoef(utrain,vtrain); corruvtrain = corr(1,2);
if testfrac > 0.; %((
[utest,vtest,Jtest] = mapuv(xtest,ytest,W);  % test data
corr = corrcoef(utest,vtest); corruvtest = corr(1,2);
end; %))
if iprint == 2; %(((
fprintf(1,'\n no.iter.   corr(train)   corr(test) '); 
fprintf(1,'\n %6.0f    %10.5f    %10.5f',iter,corruvtrain,corruvtest); 
end; %)))
if iprint == 3; %(((
fprintf(1,'\n no.iter.   corr(train)   corr(test)    J(train)     J(test) '); 
fprintf(1,'\n %6.0f    %10.5f    %10.5f  %10.5g  %10.5g',...
  iter,corruvtrain,corruvtest,Jtrain,Jtest); 
end; %)))

%----------------------------------------------------------
for loop = 1:maxloop; %[[[[[  repeated early stopping checks
%%%% work on training data
W = fminu('costfn',W,options);
[utrain,vtrain,Jtrain] = mapuv(xtrain,ytrain,W);
corr = corrcoef(utrain,vtrain); corruvtrain = corr(1,2);

%%%% work on test data
if testfrac > 0.; %[[[
[utest,vtest,Jtest] = mapuv(xtest,ytest,W);
corr = corrcoef(utest,vtest); corruvtest = corr(1,2);

%%% test for early stopping
if corruvtest > (1-sign(corruvold)*earlystop_tol)*corruvold; %((((continue
 if corruvtest > corruvold; %(((  save as 'old'
corruvold = corruvtest; iterold = iter;  
Jtrainold = Jtrain; Jtestold = Jtest; 
corruvtrainold = corruvtrain; corruvtestold = corruvtest;
utrainold = utrain; vtrainold = vtrain; 
utestold = utest; vtestold = vtest; Wold = W;
 end; %)))
else %----- stop early
if iprint == 2; %(((
fprintf(1,'\n %6.0f    %10.5f    %10.5f, stop early',...
  iter,corruvtrain,corruvtest); 
end; %)))
if iprint == 3; %(((
fprintf(1,'\n %6.0f    %10.5f    %10.5f  %10.5g  %10.5g, stop early',...
  iter,corruvtrain,corruvtest,Jtrain,Jtest); 
end; %)))

% restore 'old' results
iter = iterold; Jtrain = Jtrainold; Jtest = Jtestold;
corruvtrain = corruvtrainold; corruvtest = corruvtestold; 
utrain = utrainold; vtrain = vtrainold; 
utest = utestold; vtest = vtestold; W = Wold;
if iprint == 2; %(((
fprintf(1,'\n %6.0f    %10.5f    %10.5f',iter,corruvtrain,corruvtest); 
end; %)))
if iprint == 3; %(((
fprintf(1,'\n %6.0f    %10.5f    %10.5f  %10.5g  %10.5g',...
  iter,corruvtrain,corruvtest,Jtrain,Jtest); 
end; %)))
break  % break out of loop
end %))))
end %]]] 

if iprint ==2 & mod(loop,printskip)== 0; 
fprintf(1,'\n %6.0f    %10.5g    %10.5g',iter,corruvtrain,corruvtest); 
end;
if iprint == 3 & mod(loop,printskip)== 0; 
fprintf(1,'\n %6.0f    %10.5f    %10.5f  %10.5g  %10.5g',...
  iter,corruvtrain,corruvtest,Jtrain,Jtest); 
end; 

% if converged, break loop
if abs((corruvtrain-corruvtrainprev)/corruvtrain) < 1.e-6; %(((
 if mod(loop,printskip) ~= 0; %((
  if iprint == 2; 
  fprintf(1,'\n %6.0f    %10.5f    %10.5f',iter,corruvtrain,corruvtest); 
  end; 
  if iprint == 3; 
  fprintf(1,'\n %6.0f    %10.5f    %10.5f  %10.5g  %10.5g',...
    iter,corruvtrain,corruvtest,Jtrain,Jtest); 
  end; 
 end; %))
break; 
end; %)))

corruvtrainprev  = corruvtrain;
end; %]]]]]----------------------------------------------------

[u,v,J] = mapuv(xdata,ydata,W);
corr = corrcoef(u,v); corruv = corr(1,2);
if iprint >=2; fprintf(1,'\n  Correlation (u,v) = %6.4f ',corruv);end;
if testfrac>0; ens_delcorruv(iensemble) = corruvtest-corruvtrain; end;

%%%% conditions for keeping sol'n (to avoid overfitting):
if linear == 1 |(testfrac == 0 | ...
     corruvtest >= corruvtrain*(1-overfit_tol)); %[[[[
ens_accept(iensemble) = 1; % index indicating accepted ensemble member
if  testfrac > 0 & iprint >=2; fprintf(1,',  accept '); end;
 if corruv  > correns %[[[ choose as best in the ensemble
correns = corruv;
correns_train= corruvtrain; 
correns_test= corruvtest;
soln_utrain = utrain; soln_vtrain = vtrain;  soln_W = W;
if testfrac > 0; soln_utest = utest; soln_vtest = vtest; end;
 end %]]]
end;%]]]]

%%%% save ensemble solutions
ens_corruv(iensemble) = corruv; 
ens_W(:,:,iensemble) = W;
if isave >=2; %((((
ens_utrain(:,:,iensemble) = utrain; ens_vtrain(:,:,iensemble) = vtrain; 
if testfrac > 0; %((
ens_utest(:,:,iensemble) = utest; ens_vtest(:,:,iensemble) = vtest;
end; %))
end %))))

end %}}}}}}-------------------------------------------------------

if correns == -1; 
err_msg1 = '\n### ERROR ###: No ensemble member has been accepted as solution'; 
err_msg2 = '(for x,y -> u,v). Incr. penalty, nensemble or overfit_tol.';
err_msg = [err_msg1, err_msg2];
error(err_msg)
end;

%%%% if overfit_tol = 0, program estimates a new overfit_tol2 
%    and looks over the ensemble solutions with overfit_tol2
%    to accept some previously rejected solutions.
if testfrac > 0 & overfit_tol == 0; %{{{{{ ---------------------------------
zz = ens_accept.*norm(ens_corruv)^2;
overfit_tol2 = abs(zz*ens_delcorruv')/sum(zz);
fprintf(1,'\n\nProgram estimates new overfit_tol2 = %9.4g',overfit_tol2);

inewbestsoln=0;
for iensemble = 1: nensemble; %[[[[
if ens_accept(iensemble)==0 & -ens_delcorruv(iensemble)<overfit_tol2; %[[[
ens_accept(iensemble) = 1;
if iprint >= 2; 
fprintf(1,'\n Ensemble member number %4.0f is now accepted',iensemble); 
end;
% Check if there is a new 'best' solution
if ens_corruv(iensemble) > correns; 
correns = ens_corruv(iensemble);
W = ens_W(:,:,iensemble); inewbestsoln =1;
end; %]]
end; %]]]
end; %]]]]

if inewbestsoln == 1; %[[[ calculate the new best sol'n
[utrain,vtrain] = mapuv(xtrain,ytrain,W); % training data
soln_utrain = utrain; soln_vtrain = vtrain;  soln_W = W;
[utest,vtest] = mapuv(xtest,ytest,W);  % test data
if testfrac > 0.; %((
soln_utest = utest; soln_vtest = vtest;
end %))
end; %]]]

end %}}}}}-------------------------------------------------

if iprint >=1;
fprintf(1,'\n## Best solution in ensemble has correlation(u,v) = %7.4f',correns)
if testfrac > 0;
zz='\n##%4.0f out of %4.0f ensemble members accepted by the overfit test.';
fprintf(1,zz,sum(ens_accept),nensemble);
end;
end;

utrain = soln_utrain; vtrain = soln_vtrain; W = soln_W;
if testfrac > 0; utest = soln_utest; vtest = soln_vtest; end;
[u,v] = mapuv(xdata,ydata,W); % calculate u,v from the best W sol'n.

%=================  Inverse mapping NN (u -> x) ===========================
if iprint>=2; fprintf(1,'\n\n## Inverse mapping problem from u to x: \n'); end;
fit1ens = 1.e88; J1test = 0;  ens_accept1 = zeros(1,nensemble);
ens_MSEx = zeros(1,nensemble); ens_delMSEx = zeros(1,nensemble);
MSExtest = 0;

for iensemble = 1: nensemble %{{{{{{ ensemble ----------------------

% Choose new training and test datasets
[n,xtrain,ytrain,ntrain,xtest,ytest,ntest,testsetindex] = ...
                    chooseTestSet(xdata,ydata,testfrac,segmentlength,0);
if testfrac>0; %((
[utrain,utest] =  chooseTestuv(u,testsetindex);
else;  utrain = u;  end %))

if iprint >=2; fprintf(1,'\nEnsemble member no.%4.0f ',iensemble); end;

% setup various matrices in the inverse mappings
hu = zeros(l2,n);
wu = zeros(l2,1);
bu = zeros(l2,1);
whu = zeros(l1,l2);
bhu = zeros(l1,1);
W1 = [wu;bu;reshape(whu,[l2*l1,1]);bhu];

% use random initial weights
W1 = (expand^iensemble)*0.25*initwt_radius(2)*(2.*rand(size(W1))-1.) ; 

% find the optimal solution for the inverse mapping problem for u
%>>>> max. no. of function iterations:
maxiterations= maxiter(2)*300*max(size(W1));
niterchk = round(maxiterations/20); %>>>> no. of iterations before
%                                     checking for early stopping
options(14)= niterchk; maxloop = round(maxiterations/niterchk);
iter = 0; J1checkold = 1.e88; J1trainprev = 1.e88;

[xitrain,J1train,MSExtrain] = invmapx(utrain,xtrain,W1); % training data
if testfrac > 0.; %((
[xitest,J1test,MSExtest] = invmapx(utest,xtest,W1); % test data
end; %))
if iprint ==2;  % print results prior to training
fprintf(1,'\n no.iter.   MSEx(train)   MSEx(test) ');
fprintf(1,'\n %6.0f    %10.5f    %10.5f',iter,MSExtrain,MSExtest); 
end;
if iprint ==3; 
fprintf(1,'\n no.iter.  MSEx(train)  MSEx(test)    J1(train)   J1(test)');
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
  iter,MSExtrain,MSExtest,J1train,J1test); 
end;

for loop = 1:maxloop; %[[[[[ repeated early stopping checks
% work on training data
W1 = fminu('costfn1',W1,options);
[xitrain,J1train,MSExtrain] = invmapx(utrain,xtrain,W1);

%%%% work on test data
if testfrac > 0.; %[[[
[xitest,J1test,MSExtest] = invmapx(utest,xtest,W1);

J1check = J1test;
%%%% check for early stopping
if J1check < (1.+ earlystop_tol)*J1checkold %(((( continue
if J1check < J1checkold;  %((( save results as 'old'
iterold = iter; J1checkold = J1check; 
J1trainold = J1train; J1testold = J1test;
MSExtrainold = MSExtrain; MSExtestold = MSExtest;
xitrainold = xitrain; xitestold = xitest;  W1old = W1;
end; %)))
else %--- stop early
if iprint == 2;
fprintf(1,'\n %6.0f   %10.5f   %10.5f ,  stop early',iter,MSExtrain,MSExtest);
end;
if iprint == 3;
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g,  stop early',...
  iter,MSExtrain,MSExtest,J1train,J1test);
end;
% restore 'old' results
iter = iterold;  MSExtrain =  MSExtrainold; MSExtest = MSExtestold; 
J1train = J1trainold; J1test = J1testold;
xitrain = xitrainold; xitest = xitestold;  W1 = W1old;
if iprint == 2;
fprintf(1,'\n %6.0f   %10.5f   %10.5f',iter,MSExtrain,MSExtest);
end;
if iprint == 3;
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
  iter,MSExtrain,MSExtest,J1train,J1test);
end;
break  % break out of loop
end %))))
end %]]]

if iprint == 2 & mod(loop,printskip)== 0;
fprintf(1,'\n %6.0f   %10.5f   %10.5f',iter,MSExtrain,MSExtest); 
end;
if iprint == 3 & mod(loop,printskip)== 0;
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
  iter,MSExtrain,MSExtest,J1train,J1test);
end;

% if converged, break loop
if abs((J1train-J1trainprev)/J1train) < 1.e-6; %(((
 if mod(loop,printskip) ~= 0; %((
  if iprint == 2;
  fprintf(1,'\n %6.0f   %10.5f   %10.5f',iter,MSExtrain,MSExtest);
  end;
  if iprint == 3;
  fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
    iter,MSExtrain,MSExtest,J1train,J1test);
  end;
 end; %))
break; 
end; %)))

J1trainprev = J1train;
end; %]]]]]--------------------------------------------

fit1 = (MSExtrain*ntrain + MSExtest*ntest)/n;
if iprint >=2; fprintf(1,'\n  MSE(x) = %10.5g',fit1); end;
if testfrac>0; ens_delMSEx(iensemble) = MSExtest - MSExtrain; end;

% if no overfitting, accept sol'n:
if linear == 1 | (testfrac ==0 | ...
         MSExtest <= MSExtrain*(1+overfit_tol)) %[[[[ if true, keep sol'n
ens_accept1(iensemble) = 1; % index indicating accepted ensemble member
if testfrac > 0 & iprint >=2; fprintf(1,',  accept'); end;
 if fit1 < fit1ens %[[[ choose as best among the ensemble?
fit1ens = fit1;
soln_xitrain = xitrain; soln_W1 = W1;
if testfrac > 0; soln_xitest = xitest; end;
 end %]]]
end %]]]]

%%%% save ensemble solutions
if iensemble == 1;
ens_W1 = zeros(size(W1,1),size(W1,2),nensemble);
end;
ens_MSEx(iensemble) = fit1; 
ens_W1(:,:,iensemble) = W1;
if isave >=2; %((((
ens_xitrain(:,:,iensemble) = xitrain;
if testfrac > 0; %((
ens_xitest(:,:,iensemble) = xitest;
end; %))
end %))))

end %}}}}}}-----------------------------------------------------

if fit1ens == 1.e88; 
err_msg1 = '### ERROR ###: No ensemble member has been accepted as solution'; 
err_msg2 = ' (for u -> x). Incr. penalty, nensemble or overfit_tol.';
err_msg = [err_msg1, err_msg2];
error(err_msg)
end;

%%%% if overfit_tol = 0, program estimates a new overfit_tol2x 
%    and looks over the ensemble solutions with overfit_tol2x
%    to accept some previously rejected solutions.
if testfrac > 0 & overfit_tol == 0; %{{{{{ ---------------------------------
zz = ens_accept1./ens_MSEx;
overfit_tol2x = abs(zz*ens_delMSEx')/sum(zz);
fprintf(1,'\n\nProgram estimates new overfit_tol2x = %9.4g',overfit_tol2x);

inewbestsoln=0;
for iensemble = 1: nensemble; %[[[[
if ens_accept1(iensemble)==0 & ens_delMSEx(iensemble)<overfit_tol2x; %[[[
ens_accept1(iensemble) = 1;
if iprint >= 2; 
fprintf(1,'\n Ensemble member number %4.0f is now accepted',iensemble); 
end;
if ens_MSEx(iensemble) < fit1ens; %[[ New 'best' sol'n found
fit1ens = ens_MSEx(iensemble); W1 = ens_W1(:,:,iensemble); inewbestsoln =1;
end; %]]
end; %]]]
end; %]]]]

if inewbestsoln == 1; %[[[ calculate the new best sol'n
[xitrain,J1train,MSExtrain] = invmapx(utrain,xtrain,W1); % training data
soln_xitrain = xitrain;  soln_W1 = W1;
[xitest,J1test,MSExtest] = invmapx(utest,xtest,W1); % test data
soln_xitest = xitest;
end; %]]]
end %}}}}}-------------------------------------------------

if iprint>=1 & testfrac > 0;
zz='\n##%4.0f out of %4.0f ensemble members accepted by the overfit test.';
fprintf(1,zz,sum(ens_accept1),nensemble);
end;

%================ Inverse mapping NN (v -> y) ===============================
if iprint >= 2; fprintf(1,'\n\n## Inverse mapping problem from v to y: \n'); end;
fit2ens = 1.e88; J2test = 0; ens_accept2 = zeros(1,nensemble);
ens_MSEy = zeros(1,nensemble); ens_delMSEy = zeros(1,nensemble);
MSEytest = 0;

for iensemble = 1: nensemble %{{{{{{ ensemble

% Choose new training and test datasets
[n,xtrain,ytrain,ntrain,xtest,ytest,ntest,testsetindex] = ...
                    chooseTestSet(xdata,ydata,testfrac,segmentlength,0);
if testfrac>0; %((
[vtrain,vtest] =  chooseTestuv(v,testsetindex);
else; vtrain = v; end; %))

if iprint >=2; fprintf(1,'\nEnsemble member no.%4.0f ',iensemble); end;

% setup various matrices in the inverse mappings
hv = zeros(m2,n);
wv = zeros(m2,1);
bv = zeros(m2,1);
whv = zeros(m1,m2);
bhv = zeros(m1,1);
W2 = [wv;bv;reshape(whv,[m2*m1,1]);bhv];

% use random initial weights
W2 = (expand^iensemble)*0.25*initwt_radius(3)*(2.*rand(size(W2))-1.); 

% find the optimal solution for the inverse mapping problem for v
%>>>>max. no. of function iterations:
maxiterations= maxiter(3)*300*max(size(W2));
niterchk = round(maxiterations/20); %>>>> no. of iterations before 
%                                      checking for early stopping
options(14)= niterchk; maxloop = round(maxiterations/niterchk);
iter = 0; J2checkold = 1.e88; J2trainprev = 1.e88;

[yitrain,J2train,MSEytrain] = invmapy(vtrain,ytrain,W2); % training data
if testfrac > 0; %((
[yitest,J2test,MSEytest] = invmapy(vtest,ytest,W2); % test data
end; %))
if iprint ==2;  % print results prior to training
fprintf(1,'\n no.iter.  MSEy(train)  MSEy(test) '); 
fprintf(1,'\n %6.0f    %10.5f    %10.5f',iter,MSEytrain,MSEytest); 
end;
if iprint ==3;  % print results prior to training
fprintf(1,'\n no.iter.  MSEy(train)  MSEy(test)   J2(train)   J2(test)'); 
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
  iter,MSEytrain,MSEytest,J2train,J2test); 
end;

for loop = 1:maxloop; %[[[[[  repeated early stopping checks
% work on training data
W2 = fminu('costfn2',W2,options);
[yitrain,J2train,MSEytrain] = invmapy(vtrain,ytrain,W2);

%%%% work on test data
if testfrac > 0; %[[[
[yitest,J2test,MSEytest] = invmapy(vtest,ytest,W2);

J2check = J2test;
%%%% check for early stopping
if J2check < (1.+ earlystop_tol)*J2checkold %(((( continue
if J2check < J2checkold;  %((( save results as 'old'
iterold = iter; J2checkold = J2check; 
J2trainold = J2train; J2testold = J2test;
MSEytrainold = MSEytrain; MSEytestold = MSEytest;
yitrainold = yitrain; yitestold = yitest;  W2old = W2;
end; %)))
else %--- stop early
if iprint == 2;
fprintf(1,'\n %6.0f   %10.5f   %10.5f ,  stop early',iter,MSEytrain,MSEytest);
end;
if iprint == 3;
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g,  stop early',...
  iter,MSEytrain,MSEytest,J2train,J2test);
end;
% restore 'old' results
iter = iterold; J2train = J2trainold; J2test = J2testold; 
MSEytrain = MSEytrainold; MSEytest = MSEytestold;
yitrain = yitrainold; yitest = yitestold;  W2 = W2old;
if iprint == 2;
fprintf(1,'\n %6.0f   %10.5f   %10.5f',iter,MSEytrain,MSEytest);
end;
if iprint == 3;
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
  iter,MSEytrain,MSEytest,J2train,J2test);
end;
break  % break out of loop
end %))))
end %]]]

if iprint == 2 & mod(loop,printskip)== 0; 
fprintf(1,'\n %6.0f   %10.5f   %10.5f',iter,MSEytrain,MSEytest)
end;
if iprint == 3 & mod(loop,printskip)== 0;
fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
  iter,MSEytrain,MSEytest,J2train,J2test);
end

% if converged, break loop
if abs((J2train-J2trainprev)/J2train) < 1.e-6; %(((
 if mod(loop,printskip) ~= 0; %((
  if iprint == 2;
  fprintf(1,'\n %6.0f   %10.5f   %10.5f',iter,MSEytrain,MSEytest);
  end;
  if iprint == 3;
  fprintf(1,'\n %6.0f   %10.5f   %10.5f  %10.5g  %10.5g',...
   iter,MSEytrain,MSEytest,J2train,J2test);
  end;
 end; %))
break; 
end; %)))

J2trainprev = J2train;
end; %]]]]]--------------------------------------------

fit2 = (MSEytrain*ntrain + MSEytest*ntest)/n;
if iprint >=2; fprintf(1,'\n  MSE(y) = %10.5g',fit2); end;
if testfrac>0; ens_delMSEy(iensemble) = MSEytest - MSEytrain; end;

% if no overfitting, accept sol'n:
if linear == 1 | (testfrac ==0 | ...
    MSEytest <= MSEytrain*(1+overfit_tol)); %[[[[ if true, keep sol'n
ens_accept2(iensemble) = 1; % index indicating accepted ensemble member
if testfrac > 0 & iprint >=2; fprintf(1,',  accept'); end;
 if fit2 < fit2ens %[[[ choose as best among the ensemble?
fit2ens = fit2;
soln_yitrain = yitrain; soln_W2 = W2;
if testfrac > 0; soln_yitest = yitest; end;
 end %]]]
end; %]]]]

%%%% save ensemble solutions
if iensemble == 1;
ens_W2 = zeros(size(W2,1),size(W2,2),nensemble);
end;
ens_MSEy(iensemble) = fit2; 
ens_W2(:,:,iensemble) = W2;
if isave >=2; %((((
ens_yitrain(:,:,iensemble) = yitrain;
if testfrac > 0; %((
ens_yitest(:,:,iensemble) = yitest;
end; %))
end %))))

end %}}}}}}----------------------------------------------------

if fit2ens == 1.e88; 
err_msg1 = '### ERROR ###: No ensemble member has been accepted as solution'; 
err_msg2 = ' (for v -> y). Incr. penalty, nensemble or overfit_tol.';
err_msg = [err_msg1, err_msg2];
error(err_msg);
end;

%%%% if overfit_tol = 0, program estimates a new overfit_tol2y 
%    and looks over the ensemble solutions with overfit_tol2y
%    to accept some previously rejected solutions.
if testfrac > 0 & overfit_tol == 0; %{{{{{ ---------------------------------
zz = ens_accept2./ens_MSEy;
overfit_tol2y = abs(zz*ens_delMSEy')/sum(zz);
fprintf(1,'\n\nProgram estimates new overfit_tol2y = %9.4g',overfit_tol2y);

inewbestsoln=0;
for iensemble = 1: nensemble; %[[[[
if ens_accept2(iensemble)==0 & ens_delMSEy(iensemble)<overfit_tol2y; %[[[
ens_accept2(iensemble) = 1;
if iprint >= 2; 
fprintf(1,'\n Ensemble member number %4.0f is now accepted',iensemble); 
end;
if ens_MSEy(iensemble) < fit2ens; %[[ New 'best' sol'n found
fit2ens = ens_MSEy(iensemble); W2 = ens_W2(:,:,iensemble); inewbestsoln =1;
end; %]]
end; %]]]
end; %]]]]

if inewbestsoln == 1; %[[[ calculate the new best sol'n
[yitrain,J2train,MSEytrain] = invmapy(vtrain,ytrain,W2); % training data
soln_yitrain = yitrain;  soln_W2 = W2;
[yitest,J2test,MSEytest] = invmapy(vtest,ytest,W2); % test data
soln_yitest = yitest;
end; %]]]
end %}}}}}-------------------------------------------------

if iprint>=1 & testfrac > 0;
zz='\n##%4.0f out of %4.0f ensemble members accepted by the overfit test.';
fprintf(1,zz,sum(ens_accept2),nensemble);
end

%======================== wrapping up ===================================

% Rename variables before saving
W = soln_W; W1 = soln_W1; W2 = soln_W2;
xitrain = soln_xitrain;  yitrain = soln_yitrain; 
utrain = soln_utrain;  vtrain = soln_vtrain; 
if testfrac > 0;
xitest = soln_xitest;  yitest = soln_yitest;
utest = soln_utest; vtest = soln_vtest;
end;

[xi,J1,MSEx] = invmapx(u,xdata,W1);
[yi,J2,MSEy] = invmapy(v,ydata,W2); 
corr = corrcoef(u,v); corruv =  corr(1,2);

%%%% scale x & y variables if needed to original dimensions
if scaling(1) >= 0; %((
[xdata] = dimen(xdata',xmean,xstd,scaling(1))'; 
[xi] = dimen(xi',xmean,xstd,scaling(1))';
[xitrain] = dimen(xitrain',xmean,xstd,scaling(1))';
if testfrac >0; [xitest] = dimen(xitest',xmean,xstd,scaling(1))'; end;
end %))
if scaling(2) >= 0; %((
[ydata] = dimen(ydata',ymean,ystd,scaling(2))'; 
[yi] = dimen(yi',ymean,ystd,scaling(2))';
[yitrain] = dimen(yitrain',ymean,ystd,scaling(2))';
if testfrac >0; [yitest] = dimen(yitest',ymean,ystd,scaling(2))'; end;
end %))

if iprint >=1; %((((
fprintf(1,'\nFinal results:\n### MSE(x) = %10.5f ',MSEx);
if scaling(1) >=0; %((  calculate dimensionalized MSEx
  MSExdim = sum(diag((xi-xdata)*(xi-xdata)'))/n;
  fprintf(1,' =  %10.5g (dimensionalized)',MSExdim);
end %))
fprintf(1,'\n### MSE(y) = %10.5f ',MSEy);
if scaling(2) >=0; %((  calculate dimensionalized MSEy
  MSEydim = sum(diag((yi-ydata)*(yi-ydata)'))/n;
  fprintf(1,' =  %10.5g (dimensionalized)',MSEydim);
end %))
fprintf(1,'\n### correlation between u,v (all data): %7.4f',corruv);
meanu2 = u*u'/n; meanv2 = v*v'/n;
fprintf(1,'\n mean(u^2) =%9.4g,   mean(v^2)=%9.4g \n',meanu2,meanv2);
if (meanu2-1)^2 > 0.04 | (meanv2-1)^2 > 0.04; %((
fprintf('### WARNING ###  mean(u^2) or mean(v^2) not close to unity')
end; %))
end; %))))
