% plot mode 2 from NLCCA program
% produces (encapsuled) postscript files temp2x.eps and temp2y.eps.
clear all;

load linmode2_h1 % load linear CCA mode 2
xlin = xi; ylin = yi;
% locate the end coordinates of the line described by the linear mode.
[xl(1,1),imax] = max(xlin(1,:)); [xl(1,2),imin] = min(xlin(1,:));
xl(2,1) = xlin(2,imax); xl(2,2) = xlin(2,imin);
xl(3,1) = xlin(3,imax); xl(3,2) = xlin(3,imin);
[yl(1,1),jmax] = max(ylin(1,:)); [yl(1,2),jmin] = min(ylin(1,:));
yl(2,1) = ylin(2,jmax); yl(2,2) = ylin(2,jmin);
yl(3,1) = ylin(3,jmax); yl(3,2) = ylin(3,jmin);


load mode2_h3; % load NLCCA mode 2 %<<<< try also mode2_h2 <<<<<<<<<<
x = xdata;  y = ydata;

figure; % plot the x variables (NLCCA as circles, CCA as dashed line)
subplot(2,2,1);
plot(xl(1,:),xl(2,:),'-',x(1,:),x(2,:),'.',xi(1,:),xi(2,:),'o','Markersize',4);
title('(a)','FontSize',13)
xlabel('x_1','FontSize',12)
ylabel('x_2','FontSize',12)

subplot(2,2,2);
plot(xl(1,:),xl(3,:),'-',x(1,:),x(3,:),'.',xi(1,:),xi(3,:),'o','Markersize',4);
title('(b)','FontSize',13)
xlabel('x_1','FontSize',12)
ylabel('x_3','FontSize',12)

subplot(2,2,3);
plot(xl(2,:),xl(3,:),'-',x(2,:),x(3,:),'.',xi(2,:),xi(3,:),'o','Markersize',4);
title('(c)','FontSize',13)
xlabel('x_2','FontSize',12)
ylabel('x_3','FontSize',12)

subplot(2,2,4);
plot3(xl(1,:),xl(2,:),xl(3,:),'-',xi(1,:),xi(2,:),xi(3,:),'o','Markersize',4);

view([-32.5,40]); %<<<<< vary view angles for different 3D perspective

title('(d)','FontSize',13)
xlabel('x_1','FontSize',12)
ylabel('x_2','FontSize',12)
zlabel('x_3','FontSize',12)
box off; grid on;

print -deps temp2x.eps

figure; % plot the y variables
subplot(2,2,1);
plot(yl(1,:),yl(2,:),'-',y(1,:),y(2,:),'.',yi(1,:),yi(2,:),'o','Markersize',4);
title('(a)','FontSize',13);
xlabel('y_1','FontSize',12);
ylabel('y_2','FontSize',12);

subplot(2,2,2);
plot(yl(1,:),yl(3,:),'-',y(1,:),y(3,:),'.',yi(1,:),yi(3,:),'o','Markersize',4);
title('(b)','FontSize',13);
xlabel('y_1','FontSize',12);
ylabel('y_3','FontSize',12);

subplot(2,2,3);
plot(yl(2,:),yl(3,:),'-',y(2,:),y(3,:),'.',yi(2,:),yi(3,:),'o','Markersize',4);
title('(c)','FontSize',13);
xlabel('y_2','FontSize',12);
ylabel('y_3','FontSize',12);

subplot(2,2,4);
plot3(yl(1,:),yl(2,:),yl(3,:),'-',yi(1,:),yi(2,:),yi(3,:),'o','Markersize',4);

view([-32.5,40]); %<<<<< vary view angles for different 3D perspective

title('(d)','FontSize',13);
xlabel('y_1','FontSize',12);
ylabel('y_2','FontSize',12);
zlabel('y_3','FontSize',12);
box off; grid on;

print -deps temp2y.eps
