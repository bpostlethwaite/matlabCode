function [u,v,xi,yi] = extracalc(xdata,ydata,W,W1,W2)
% function [u,v,xi,yi] = extracalc(xdata,ydata,W,W1,W2)
% Performs extra calculations with NLCCA. Given xdata, ydata, 
% W, W1 & W2, computes the canonical variates u, v and xi, yi 
% (the NLCCA approximation to xdata & ydata).
% This optional function is useful if after the networks have been trained, 
% some new data xdatanew, ydatanew become available, then to get the
% u,v,xi,yi for the new data (without retraining the neworks), do
% [u,v,xi,yi] = extracalc(xdatanew,ydatanew,W,W1,W2)

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol scaling penalty maxiter initRand ...
  initwt_radius options n l1 m1 l2 m2 iter xmean xstd ymean ystd...
  ntrain xtrain ytrain utrain vtrain xitrain yitrain ...
  ntest xtest ytest utest vtest xitest yitest corruv MSEx MSEy ...
  ens_accept ens_accept1 ens_accept2 ens_corruv ens_MSEx ens_MSEy ...
  ens_W ens_W1 ens_W2 ens_utrain ens_vtrain ens_xitrain ens_yitrain ...
  ens_utest ens_vtest ens_xitest ens_yitest 

%%%% scales xdata  if scaling(1) >=0.
if scaling(1) >=0; %((
[xdata] = nondimen(xdata',scaling(1),xmean,xstd);
xdata = xdata';
end %))
%%%% scales ydata  if scaling(2) >=0.
if scaling(2) >=0; %((
[ydata] = nondimen(ydata',scaling(2),ymean,ystd);
ydata = ydata';
end %))

[u,v] = mapuv(xdata,ydata,W);
[xi] = invmapx(u,xdata,W1);
[yi] = invmapy(v,ydata,W2);

%%%% scale x & y variables if needed to original dimensions
if scaling(1) >= 0; %((
[xdata] = dimen(xdata',xmean,xstd,scaling(1))'; 
[xi] = dimen(xi',xmean,xstd,scaling(1))';
end %))
if scaling(2) >= 0; %((
[ydata] = dimen(ydata',ymean,ystd,scaling(2))'; 
[yi] = dimen(yi',ymean,ystd,scaling(2))';
end %))
