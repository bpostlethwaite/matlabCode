function [xi,J,J0] = invmapx(u,x,W)
% function [xi,J,J0] = invmapx(u,x,W)
% Inverse map from u to xi. J is the cost fn; J0 is the MSEx*Jscale.

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options  n l m nbottle iter Jscale xmean xstd...
  ntrain xtrain utrain xitrain ntest xtest utest xitest MSEx ...
  ens_accept ens_MSEx ens_W ens_utrain ens_xitrain ens_utest ens_xitest

[mm,nn]= size(u);
one = ones(1,nn);
lm = l*m;

ibeg = (lm+m+(m+1)*nbottle) + 1;
iend= ibeg -1 + m*nbottle;
wu = reshape(W(ibeg:iend),[m,nbottle]);
ibeg=iend+1;
iend=iend+m;
bu = W(ibeg:iend);
ibeg=iend+1;
iend=iend+lm;
whu = reshape(W(ibeg:iend),[l,m]);
ibeg=iend+1;
iend=iend+l;
bhu = W(ibeg:iend);

hu = zeros(m,nn);

if linear == 0 %((( nonlinear
hu = tanh(wu*u + bu*one);
else %--- linear
hu = wu*u + bu*one;
end %)))

xi = whu*hu + bhu*one;

J0 = sum(diag((xi-x)*(xi-x)'))/nn*Jscale;
% add the normalization condition u*u'/nn = 1, and mean(u) = 0
J = J0 +sum(diag((u*u'/nn - ones(nbottle,nbottle)).^2)) +sum(mean(u').^2);
if penalty ~= 0; J = J + penalty*norm(W(1:lm))^2; end; % add penalty term?



