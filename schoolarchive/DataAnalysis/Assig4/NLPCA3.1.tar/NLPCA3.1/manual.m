function manual
% Nonlinear Principal Component Analysis (NLPCA version 3.1) online manual
%        Copyright (C) 2005   William W. Hsieh
%
% Three functions fminu.m, updhess.m and optint.m from the MATLAB Optimization
% Toolbox are no longer available in MATLAB 7, so you may have to download 
% these missing M-files from 
% http://www.ocgy.ubc.ca/projects/clim.pred/download.html.
%
% Files in this directory:
%
% setdat.m sets up the demo problem, produces a demo dataset data1.mat.
%------------
% nlpca1.m is the main program for calculating the NLPCA mode 1.
%    (Here the dataset xdata is loaded).
% nlpca2.m is the main program for calculating the NLPCA mode 2.
%
% param.m contains the parameters for the problem.
%
% chooseTestSet.m divides the dataset into a training set & a test set.
%
% calcmode.m computes the NLPCA mode (or PCA mode).
%
% costfn.m computes the costfn.
% mapu.m maps x -> u.
% invmapx.m computes the inverse map u -> xi.
% nondimen.m & dimen.m are used for scaling & descaling the data.
%
% extracalc.m (optional) can be used for projecting new data onto an
%   NLPCA mode, or for examining the solution of any ensemble member.
%-------------
%
% out1 & out2 are the printouts from running nlpca1 & nlpca2 respectively.
% mode1_m1.mat, ..., mode1_m4.mat are the extracted nonlinear mode 1 
%          with no. of hidden neurons m = 1,2,3,4.
% After removing mode1_m2.mat from the data, the second mode was
% extracted, again with m varying from 1 to 4, yielding the files
% mode2_m1.mat,... mode2_m4.mat.
% linmode1.mat is the extracted linear mode 1.
% plmode1.m or pltmode1.m plots the output mode 1.
% plmode2.m or pltmode2.m plots the output mode 2.
%======================================================================%
% The parameters are stored in param.m.:
% Parameters are classified into 3 categories, `*' means user normally has
% to change the value to fit the problem. `+' means user may want to
% change the value, and `-' means user rarely has to change the value.
%
%+ iprint = 0, 1, or 2 increases the amount of printout.
%
%- isave = 1 only saves the best sol'n in a .mat file, 
%              plus W and MSEx of all ensemble members.
%        = 2 saves all ensemble member sol'ns (more memory required).
%
%- linear = 0 means NLPCA; linear = 1 essentially reduces to PCA.
%
%* nensemble is the no. of members in the ensemble. (Many ensemble members
%            may converge to shallow local minina and hence wasted).
%
%- testfrac = 0 does not reserve a portion of the data for testing.
%          All data used for training. Best if data is rather clean.
%  testfrac > 0, say between 0.15 to 0.25, then a fraction of the data
%	   record will be randomly selected as test data. Training is
%          stopped if the MSE (mean squared error) increases in the test
%          data by more than the threshold given by earlystop_tol.
%
%+ segmentlength = 1 if autocorrelation of the data is not of concern;
%        otherwise set to about the autocorrelation time scale.
%
%- overfit_tol is the tolerance for overfitting, should be 0 (recommended)
%      or a small positive number (0.1 or less).
%      Only ensemble members having MSE over the test set no worse than
%      (MSE over the training set)*(1+overfit_tol) are accepted, 
%      and the selected solution is the member with the lowest MSE 
%      over all the data.
%      When overfit_tol = 0, program automatically chooses an overfit
%      tolerence level to decide which ensemble members to accept.
%
%- earlystop_tol  should be around 0.05 to 0.15. (0.1 recommended).
%      This is the 'early stopping' method. Best if data is noisy, i.e.
%      overtraining to fit the noise in the data is to be prevented.
%
%+ xscaling  controls scaling of the x variables before performing NLPCA. 
%      = -1, no scaling (not recommended unless variables are of order 1).
%      = 0, scales all x variables by removing the mean & dividing by the
%      standard deviation of each variable. 
%      = 1, scales all x variables by removing the mean & dividing by the
%      standard deviation of the 1st x variable. (Etc. for 2, 3, ...)
%      When the x variables are the principal components and the 1st
%      variable is from the leading mode, xscaling = 1 is preferred.
%
%* penalty scales the wt. penalty term in the cost function. If 0, no
%      penalty used, while 1e-6 to 0.1 uses a reasonable amount of
%      wt. penalty.  Increasing the penalty leads to less
%      nonlinearity (i.e. less wiggles & zigzags when fitting to
%      the data).
%
%+ maxiter scales the maximum number of function iterations allowed 
%      during optimization. Start with 1, increase if needed.
%
%+ initRand =  a positive integer, initializes the random number
%             generator, used for random initial weights.
%
%- initwt_radius controls the initial random wt. radius for the ensemble
%      Adjust this parameter if having convergence problem.
%      (Suggest starting with initwt_radius = 1). The wt. radius is
%      smallest for the first ensemble member, increasing by a factor
%      of 4 when the final ensemble member is reached (so the earliest
%      ensemble members tend to be more linear than the later members).
%
% input dimensions of the networks:
%* l is the no. of x variables
%* m is the no. of hidden neurons after the l x-variables
%- nbottle is the number of bottleneck neurons (usually 1).
%
%-------------------------
% Global variables are:
% global  iprint isave linear nensemble testfrac segmentlength ...
%  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
%  initwt_radius options  n l m nbottle iter Jscale xmean xstd...
%  ntrain xtrain utrain xitrain ntest xtest utest xitest MSEx ...
%  ens_accept ens_MSEx ens_W ens_utrain ens_xitrain ens_utest ens_xitest
%
%                   !!!!!!!!!!!!!!!!!!!!!!!!!!!
% If you add or remove variables from this global list, it is CRITICAL
% that the same changes are made on ALL of the following files:
% nlpca1.m, nlpca2.m, param.m, calcmode.m, costfn.m, mapu.m, invmapx.m,
% extracalc.m.
%                   !!!!!!!!!!!!!!!!!!!!!!!!!!!
%
% options are the options used for the m-file fminu.m in the matlab
%    optimization toolbox.
%
% n is the number of samples [automatically determined from xdata].
% xdata is an l*n data matrix, as there are l `x' variables, and n samples or
% time measurements.
%
% iter is the number of function iterations.
% Jscale is a scale factor for the cost function J.
% xmean & xstd are the means & standard deviations of the xdata variables.
%
% ntrain, ntest are the number of samples for training and for testing.
% xtrain, xtest are the x data used for training and testing.
% utrain, utest are the bottleneck neuron values (the NLPC) during
%               training and testing. mean(utrain) = 0, &
%               utrain*utrain'/ntrain = 1 is forced on the cost fn. J.
% xitrain, xitest are the model predicted values for x during training
%                 and testing. 
% MSEx is the mean squared error of x over all data (training+testing).
%
% ens_accept has value 1 if the ensemble member passed the overfit test,
%            otherwise 0.
% ens_MSEx saves the MSEx and ens_W the wts. W for all ensemble members.
%
% When isave = 2, all the ensemble solutions, i.e. 
%    ens_utrain ens_xitrain ens_utest ens_xitest  are saved.
%    (This could increase memory usage considerably).

