% plot output from NLPCA program. Plot mode 2. New format.
% Ignore temporary figure plotted before the final figure.
clear all;

load mode2_m4 % <*** give name of file you want to plot out
x= xdata;

% first plot is discarded
figure;
plot3(x(1,:),x(2,:),x(3,:),'.',xi(1,:),xi(2,:),xi(3,:),'square');
l1=get(gca,'XLim'); z1=max(l1); 
l2=get(gca,'YLim'); z2=max(l2);
l3=get(gca,'ZLim'); z3=min(l3);
z1 = z1*ones(1,size(xi,2)); 
z2 = z2*ones(1,size(xi,2)); 
z3 = z3*ones(1,size(xi,2));
 
figure; % 2nd plot is the desired plot
h = axes('GridLineStyle','--','FontSize',12);

plot3(xi(1,:),xi(2,:),xi(3,:),'square',...
x(1,:),x(2,:),z3,'.',xi(1,:),xi(2,:),z3,'o',...
x(1,:),z2,x(3,:),'.',xi(1,:),z2,xi(3,:),'o',...
z1,x(2,:),x(3,:),'.',z1,xi(2,:),xi(3,:),'o','Markersize',5);

set(gca,'XLim',l1,'YLim',l2,'ZLim',l3,...
'XLimmode','manual','YLimmode','manual','ZLimmode','manual');

view([-32.5,40]);  %<<<<< vary view angles for different 3D perspective

xlabel('x_{1}','FontSize',15)
ylabel('x_{2}','FontSize',15)
zlabel('x_{3}','FontSize',15)

box off; grid on;

print -deps temp2.eps
