% plot output from NLPCA program. New format
% Ignore temporary figure plotted before the final figure.
clear all;

load linmode1 % load linear PCA mode 1
xlin = xi; 
% locate the end coordinates of the line described by the linear mode.
[xl(1,1),imax] = max(xlin(1,:)); [xl(1,2),imin] = min(xlin(1,:));
xl(2,1) = xlin(2,imax); xl(2,2) = xlin(2,imin);
xl(3,1) = xlin(3,imax); xl(3,2) = xlin(3,imin);

load mode1_m2 % <*** give name of file you want to plot out
x= xdata;

% first plot is discarded
figure;
plot3(x(1,:),x(2,:),x(3,:),'.',xi(1,:),xi(2,:),xi(3,:),'square',...
xl(1,:),xl(2,:),xl(3,:),'--');
l1=get(gca,'XLim'); z1=max(l1); 
l2=get(gca,'YLim'); z2=max(l2);
l3=get(gca,'ZLim'); z3=min(l3);
zl1 = z1*ones(1,size(xl,2)); z1 = z1*ones(1,size(xi,2)); 
zl2 = z2*ones(1,size(xl,2)); z2 = z2*ones(1,size(xi,2)); 
zl3 = z3*ones(1,size(xl,2)); z3 = z3*ones(1,size(xi,2));
 
figure; % 2nd plot is the desired plot
h = axes('GridLineStyle','--','FontSize',12);

plot3(xi(1,:),xi(2,:),xi(3,:),'square',xl(1,:),xl(2,:),xl(3,:),'--',...
xl(1,:),xl(2,:),zl3,'-',x(1,:),x(2,:),z3,'.',xi(1,:),xi(2,:),z3,'o',...
xl(1,:),zl2,xl(3,:),'-',x(1,:),z2,x(3,:),'.',xi(1,:),z2,xi(3,:),'o',...
zl1,xl(2,:),xl(3,:),'-',z1,x(2,:),x(3,:),'.',z1,xi(2,:),xi(3,:),'o','Markersize',5);

set(gca,'XLim',l1,'YLim',l2,'ZLim',l3,...
'XLimmode','manual','YLimmode','manual','ZLimmode','manual');

view([-32.5,40]); %<<<<< vary view angles for different 3D perspective

xlabel('x_{1}','FontSize',15)
ylabel('x_{2}','FontSize',15)
zlabel('x_{3}','FontSize',15)

box off; grid on;

print -deps temp.eps
