function [u,xi] = extracalc(xdata,W)
% function [u,xi] = extracalc(xdata,W)
% Performs extra calculations with NLPCA. Given xdata and W, 
% computes u and xi (the NLPCA approximation to xdata).
%
% Two uses for extracalc.m:
% (1) Suppose calcmode.m has been used to find the NLPCA mode for the
% dataset xdata, and now new data are available in xdatanew, then to
% get the new u and xi values, use  
% [u,xi] = extracalc(xdatanew,W);
% 
% (2) Suppose one would like to look at the solutions (u,xi) associated
% with ensemble member j, then use
% [u,xi] = extracalc(xdata,ens_W(:,:,j));

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options  n l m nbottle iter Jscale xmean xstd...
  ntrain xtrain utrain xitrain ntest xtest utest xitest MSEx ...
  ens_accept ens_MSEx ens_W ens_utrain ens_xitrain ens_utest ens_xitest

%%%% scales xdata  if xscaling >=0.
if xscaling >=0; %((
[xdata] = nondimen(xdata',xscaling,xmean,xstd);
xdata = xdata';
end %))

[u] = mapu(xdata,W);
[xi,junk1,junk2] = invmapx(u,xdata,W);

%%%% scale x variables if needed
if xscaling >= 0; %((
% restore xdata to original size
[xdata] = dimen(xdata',xmean,xstd,xscaling)'; 
[xi] = dimen(xi',xmean,xstd,xscaling)';
end %))
