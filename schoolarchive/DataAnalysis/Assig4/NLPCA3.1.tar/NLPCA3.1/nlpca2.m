% Nonlinear principal component analysis (NLPCA) program by W.Hsieh.
% Extracts mode 2.

clear all;

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options  n l m nbottle iter Jscale xmean xstd...
  ntrain xtrain utrain xitrain ntest xtest utest xitest MSEx ...
  ens_accept ens_MSEx ens_W ens_utrain ens_xitrain ens_utest ens_xitest

%-------------------------------------------------------------------
% load input data xdata
load mode1_m2; %<<<<<<<<<<< load the mode1 file you want <<<<<<<<<<<

%  remove contributions from mode 1.
xdata = xdata - xi;

cputime0 = cputime;
param  % load parameters from file param.m

% Calculate NLPCA mode 2 --------------------------------------------
m = 1;
fprintf(1,'\n\n###> Run with number of hidden neurons m = %3.0f:',m);
[u,xi,W] = calcmode(xdata); 

% save to disc file   (tx can be left out from the save command)
save mode2_m1   n l m nbottle xdata tx u xi W  linear initRand nensemble ...
  penalty xscaling xmean xstd utrain utest xitrain xitest MSEx ...
  ens_accept ens_utrain ens_xitrain ens_utest ens_xitest ens_MSEx ens_W

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;

% Calculate NLPCA mode 2 --------------------------------------------
m = 2;
fprintf(1,'\n\n###> Run with number of hidden neurons m = %3.0f:',m);
[u,xi,W] = calcmode(xdata); 

% save to disc file
save mode2_m2   n l m nbottle xdata tx u xi W  linear initRand nensemble ...
  penalty xscaling xmean xstd  utrain utest xitrain xitest MSEx ...
  ens_accept ens_utrain ens_xitrain ens_utest ens_xitest ens_MSEx ens_W 

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;

% Calculate NLPCA mode 2 --------------------------------------------
m = 3;
fprintf(1,'\n\n###> Run with number of hidden neurons m = %3.0f:',m);
[u,xi,W] = calcmode(xdata); 

% save to disc file
save mode2_m3   n l m nbottle xdata tx u xi W  linear initRand nensemble ...
  penalty xscaling xmean xstd  utrain utest xitrain xitest MSEx ...
  ens_accept ens_utrain ens_xitrain ens_utest ens_xitest ens_MSEx ens_W

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;

% Calculate NLPCA mode 2 --------------------------------------------
m = 4;
fprintf(1,'\n\n###> Run with number of hidden neurons m = %3.0f:',m);
[u,xi,W] = calcmode(xdata); 

% save to disc file
save mode2_m4   n l m nbottle xdata tx u xi W  linear initRand nensemble ...
  penalty xscaling xmean xstd  utrain utest xitrain xitest MSEx ...
  ens_accept ens_utrain ens_xitrain ens_utest ens_xitest ens_MSEx ens_W

fprintf(1,'\n#cputime = %12.4g\n',cputime-cputime0); cputime0=cputime;



