% setup data1.mat for NLPCA test problem
% produces postscript files tempx.ps for the x data
clear all;
n = 500 % generate 500 samples

rand('state',0); % intialize uniform random no. generator
randn('state',0); % intialize normal distr. random no. generator
x = zeros(3,n);
x1 = zeros(3,n);
x2 = zeros(3,n);
t = 2*rand(1,n)-1.; % random number converted to lie in the interval (-1,1)
s = 2*rand(1,n)-1.; % random number converted to lie in the interval (-1,1)
 
% mode 1 variables
x1(1,:) = t;
x1(2,:) = t;
x1(3,:) = t.^2; 
x1 =nondimen(x1')';

% generate mode 1 for plotting
mx1 = zeros(3,41);

tt = [-1:0.05:1];
mx1(1,:) = tt;
mx1(2,:) = tt;
mx1(3,:) = tt.^2;

mx1 =nondimen(mx1')';
 
% mode 2 variables
x2(1,:) =  -s;
x2(2,:) =  s;
x2(3,:) =  -s.^4;

x2 =nondimen(x2')';

% generate mode 2 for plotting
mx2 = zeros(3,41);

ss =[-1:0.05:1];
 
mx2(1,:) =  -ss;
mx2(2,:) =  ss;
mx2(3,:) = -ss.^4;

mx2 =nondimen(mx2')';

% add mode 1 and mode 2 contributions
x2 = 0.577*x2; % scale mode 2 to have only 1/3 the variance of mode 1
mx2 = 0.577*mx2;
x = x1 + x2;
x = nondimen(x')';
x = x+0.1*randn(3,n); % add 10% Gaussian noise
x = nondimen(x')';

% rename and save data onto a file data1.mat
xdata = x; tx = t;
save data1 xdata  tx s  mx1  mx2 ;

% plot x variables ------------------------------------------------
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultAxesFontSize',9);
figure;
subplot(2,2,1);
plot(x(1,:),x(2,:),'.',mx1(1,:),mx1(2,:),'o',mx2(1,:),mx2(2,:),'-','MarkerSize',4);
title('(a)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{2}','FontSize',12)

subplot(2,2,2);
plot(x(1,:),x(3,:),'.',mx1(1,:),mx1(3,:),'o',mx2(1,:),mx2(3,:),'-','MarkerSize',4);
title('(b)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{3}','FontSize',12)

subplot(2,2,3);
plot(x(2,:),x(3,:),'.',mx1(2,:),mx1(3,:),'o',mx2(2,:),mx2(3,:),'-','MarkerSize',4);
title('(c)','FontSize',13)
xlabel('x_{2}','FontSize',12)
ylabel('x_{3}','FontSize',12)

subplot(2,2,4);
plot3(mx1(1,:),mx1(2,:),mx1(3,:),'o',mx2(1,:),mx2(2,:),mx2(3,:),'-','MarkerSize',4);
title('(d)','FontSize',13)
xlabel('x_{1}','FontSize',12)
ylabel('x_{2}','FontSize',12)
zlabel('x_{3}','FontSize',12)

print -dps tempx.ps



