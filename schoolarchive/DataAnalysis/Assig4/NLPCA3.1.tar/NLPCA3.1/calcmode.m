function [u,xi,W] = calcmode(xdata)
% function [u,xi,W] = calcmode(xdata)
% Copyright (C) 2001,2002   William W. Hsieh
% Calculates 1 NLPCA (or PCA) mode
% If there are convergence problems, one could adjust some of the
% parameters marked by '>>>>' (maxiterations, niterchk, overallexpand
% & options) in calcmode.m directly, though this is usu. not necessary.

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options  n l m nbottle iter Jscale xmean xstd...
  ntrain xtrain utrain xitrain ntest xtest utest xitest MSEx ...
  ens_accept ens_MSEx ens_W ens_utrain ens_xitrain ens_utest ens_xitest

%%%% scales xdata  if xscaling >=0.
if xscaling >=0; %((
[xdata,xmean,xstd] = nondimen(xdata',xscaling);
xdata = xdata';
end %))


if iprint > 0;
  if linear == 0; fprintf(1,'\nNLPCA nonlinear mode:\n'); end;
  if linear == 1; fprintf(1,'\nNLPCA linear mode:\n'); end;
  if penalty ~= 0;
    fprintf(1,'\n penalty =%10.5g    (nbottle =%2.0g)\n',...
            penalty,nbottle);
  end;
end;

%%%% Initialize variables 
fitens = 1.e88; Jtest = 0; MSExtest = 0; 
ens_accept = zeros(1,nensemble);
ens_MSEx = zeros(1,nensemble); ens_delMSEx = zeros(1,nensemble);

% Set the factor to expand random wt. radius between ensemble members.
overallexpand = 4; %>>>> wt. radii expand by this overall factor between
                   % the 1st ensemble member and the last.
expand = overallexpand^(1./nensemble); % wt. expand factor between
                                      % adjacent ensemble members.

% ===================================================================
for iensemble = 1: nensemble %{{{{{{ ensemble

% The record xdata is randomly divided into training
% part xtrain and testing part xtest. 
% testfrac is the fraction selected for testing.
[n,xtrain,ntrain,xtest,ntest,testsetindex] = ...
                      chooseTestSet(xdata,testfrac,segmentlength,0);

%%%% setup various matrices in the forward mapping
normx = zeros(1,ntrain);
for i = 1:ntrain; normx(i)= norm(xtrain(:,i)); end;
xscale = mean(normx);
wx = ones(m,l)/xscale;
bx = ones(m,1);
whx = ones(m,nbottle);
bhx = ones(nbottle,1);
wu = ones(m,nbottle);
bu = ones(m,1);
whu = ones(l,m)*xscale;
bhu = ones(l,1)*xscale;
utrain = zeros(nbottle,ntrain);

%%%% combine all the weight and bias parameters into a single wt vector
Wscale=[reshape(wx,[m*l,1]);bx;reshape(whx,[m*nbottle,1]);bhx;...
        reshape(wu,[m*nbottle,1]);bu;reshape(whu,[l*m,1]);bhu];
% random initial weights.
W=(expand^iensemble)*initwt_radius*0.25*(2.*rand(size(Wscale))-1.).*Wscale;

% For more info on the options in the optimization m-file fminu, 
% type: help foptions
options(1) = -1;     %  no printout from fminu. 
%>>>> termination criterion for weights in the optimization
options(2) = 1.e-5;  %>>>>
%>>>> termination criterion for cost function J
options(3) = 1.e-5;  %>>>>

if iensemble == 1; %[[[ set up matrices for the ensemble
ens_W = zeros(size(W,1),size(W,2),nensemble);
if isave >= 2 %(( 
ens_utrain = zeros(nbottle,ntrain,nensemble);
ens_xitrain = zeros(l,ntrain,nensemble);
ens_utest = zeros(nbottle,ntest,nensemble); 
ens_xitest = zeros(l,ntest,nensemble);
end; %))
end %]]]

%%%% find the optimal solution: ---------------------------------
if iprint >=2; fprintf(1,'\nEnsemble member no.%4.0f \n',iensemble);end;

%>>>> max. no. of function iterations during optimization.
maxiterations = maxiter*600*max(size(W));

%>>>> no. of iterations before checking for early stopping
niterchk = round(maxiterations/20); 

options(14)= niterchk; maxloop = round(maxiterations/niterchk);
iter = 0; loop=1; Jcheckold = 1.e88; Jtrainprev = 1.e88;

% set up scale factor Jscale for the cost fn J
Jscale = 1/(sum(diag(xtrain*xtrain'))/ntrain); 
[utrain] = mapu(xtrain,W); % forward map to u (training data)
% map back to x
[xitrain,Jtrain,J0train] = invmapx(utrain,xtrain,W);
MSExtrain = J0train/Jscale;  
if testfrac > 0.; %((
[utest] = mapu(xtest,W);  % test data
[xitest,Jtest,J0test] = invmapx(utest,xtest,W);
MSExtest = J0test/Jscale;
end; %))
if iprint == 2;  % print results prior to training
fprintf(1,' no.iter.  MSEx(train)  MSEx(test) \n');
fprintf(1,' %6.0f  %10.5f  %10.5f\n',iter,MSExtrain,MSExtest); 
end;
if iprint == 3;  % print results prior to training
fprintf(1,' no.iter.  MSEx(train)  MSEx(test)  J(train)   J(test)\n');
fprintf(1,' %6.0f  %10.5f  %10.5f %10.5g %10.5g\n',...
   iter,MSExtrain,MSExtest,Jtrain,Jtest); 
end;
%---------------------------------------------------------
for loop = 1:maxloop; %[[[[[ repeated early stopping checks
%%%% work on training data
W = fminu('costfn',W,options);
[utrain] = mapu(xtrain,W);
[xitrain,Jtrain,J0train] = invmapx(utrain,xtrain,W);
MSExtrain = J0train/Jscale; 

%%%% work on test data
if testfrac > 0.; %[[[
[utest] = mapu(xtest,W);
[xitest,Jtest,J0test] = invmapx(utest,xtest,W);
MSExtest = J0test/Jscale;

Jcheck = Jtest;
%%%% check for early stopping
if Jcheck < (1.+ earlystop_tol)*Jcheckold %(((( continue
 if Jcheck < Jcheckold; %((( % save results as 'old'
iterold = iter; Jcheckold = Jcheck;
Jtrainold = Jtrain; Jtestold = Jtest; 
MSExtrainold = MSExtrain; MSExtestold = MSExtest;
xitrainold = xitrain; xitestold = xitest;  Wold = W;
 end; %)))
else %--- stop early
if iprint ==2;
fprintf(1,' %6.0f  %10.5f  %10.5f , stop early\n',iter,MSExtrain,MSExtest);
end;
if iprint ==3;
fprintf(1,' %6.0f  %10.5f  %10.5f %10.5g %10.5g , stop early\n',...
  iter,MSExtrain,MSExtest,Jtrain,Jtest);
end;
Jtrain = Jtrainold; Jtest = Jtestold; % restore 'old' results
MSExtrain = MSExtrainold; MSExtest = MSExtestold; iter = iterold;
xitrain = xitrainold; xitest = xitestold;  W = Wold;
if iprint ==2;
fprintf(1,' %6.0f  %10.5f  %10.5f \n',iter,MSExtrain,MSExtest);
end;
if iprint ==3;
fprintf(1,' %6.0f  %10.5f  %10.5f %10.5g %10.5g \n',...
  iter,MSExtrain,MSExtest,Jtrain,Jtest);
end;
break  % break out of loop
end %))))
end %]]]

if iprint ==2;
fprintf(1,' %6.0f  %10.5f  %10.5f\n',iter,MSExtrain,MSExtest); 
end;
if iprint ==3;
fprintf(1,' %6.0f  %10.5f  %10.5f %10.5g %10.5g\n',...
  iter,MSExtrain,MSExtest,Jtrain,Jtest);
end;

%%%% if converged, break loop
if abs((Jtrainprev-Jtrain)/Jtrain) < 1.e-5; break; end;
 
Jtrainprev = Jtrain;
end; %]]]]]--------------------------------------------

fit = (MSExtrain*ntrain + MSExtest*ntest)/n;
if iprint >=2; fprintf(1,'  MSE(x) = %10.5f ',fit); end;
ens_delMSEx(iensemble) = MSExtest - MSExtrain; 

%%%% if MSExtest <= MSExtrain*(1+overfit_tol), no overfitting, 
%    so accept sol'n:
if MSExtest <= MSExtrain*(1+overfit_tol) %[[[[ 
ens_accept(iensemble) = 1; % index indicating accepted ensemble member
if iprint >=2; fprintf(1,',  accept'); end;

if fit < fitens %[[[ choose as best among the ensemble
fitens = fit;
soln_xitrain = xitrain; soln_utrain = utrain; soln_W = W;
if testfrac > 0; soln_xitest = xitest;  soln_utest = utest; end;
end %]]]
end %]]]]

%%%% save ensemble solutions
ens_MSEx(iensemble) = fit; 
ens_W(:,:,iensemble) = W;
if isave >=2; %((((
ens_utrain(:,:,iensemble) = utrain; 
ens_xitrain(:,:,iensemble) = xitrain;
if testfrac > 0; %((
ens_utest(:,:,iensemble) = utest; 
ens_xitest(:,:,iensemble) = xitest;
end; %))
end %))))

end %}}}}}}===========================================================

if fitens == 1.e88; 
err_msg1 = '\n### ERROR ###: No ensemble member has been accepted as solution.';
err_msg2 = ' Increase penalty, or nensemble or overfit_tol, or decrease m';
err_msg = [err_msg1, err_msg2];
error(err_msg)
end;

%%%% if overfit_tol = 0, program estimates a new overfit_tol2 
%    and looks over the ensemble solutions with overfit_tol2
%    to accept some previously rejected solutions.
if testfrac > 0 & overfit_tol == 0; %{{{{{ ---------------------------------
zz = ens_accept./ens_MSEx;
overfit_tol2 = abs(zz*ens_delMSEx')/sum(zz);
fprintf(1,'\n\nProgram estimates new overfit_tol2 = %9.4g',overfit_tol2);

inewbestsoln=0;
for iensemble = 1: nensemble; %[[[[
if ens_accept(iensemble)==0 & ens_delMSEx(iensemble)<overfit_tol2; %[[[
ens_accept(iensemble) = 1;
if iprint >= 2; 
fprintf(1,'\n Ensemble member number %4.0f is now accepted',iensemble); 
end;
if ens_MSEx(iensemble) < fitens; %[[ New 'best' sol'n found
fitens = ens_MSEx(iensemble); W = ens_W(:,:,iensemble); inewbestsoln =1;
end; %]]
end; %]]]
end; %]]]]

if inewbestsoln == 1; %[[[ calculate the new best sol'n
[utrain] = mapu(xtrain,W); % forward map to u (training data)
% map back to x
[xitrain,Jtrain,J0train] = invmapx(utrain,xtrain,W); 
soln_xitrain = xitrain; soln_utrain = utrain; soln_W = W;
[utest] = mapu(xtest,W); 
[xitest,Jtest,J0test] = invmapx(utest,xtest,W);
soln_xitest = xitest;  soln_utest = utest;
end; %]]]

end %}}}}}-------------------------------------------------

%%%% Rename variables before saving
W = soln_W; MSEx = fitens;
xitrain = soln_xitrain;  utrain = soln_utrain;
if testfrac >0; xitest = soln_xitest;  utest = soln_utest; end;
[u] = mapu(xdata,W);
[xi,J,junk] = invmapx(u,xdata,W);

%%%% scale x variables if needed
if xscaling >= 0; %((
% restore xdata to original size
[xdata] = dimen(xdata',xmean,xstd,xscaling)'; 
[xi] = dimen(xi',xmean,xstd,xscaling)';
[xitrain] = dimen(xitrain',xmean,xstd,xscaling)';
if testfrac >0; [xitest] = dimen(xitest',xmean,xstd,xscaling)'; end;
end %))

if iprint >=1; %(((
fprintf(1,'\nFinal results:\n### MSE(x) = %10.5f',MSEx);
if xscaling >=0; %((  calculate dimensionalized MSEx
MSExdim = sum(diag((xi-xdata)*(xi-xdata)'))/n;
fprintf(1,' =  %10.5g (dimensionalized)',MSExdim);
end %))
zz='\n###%4.0f out of %4.0f ensemble members accepted by the overfit test.';
if testfrac > 0; fprintf(1,zz,sum(ens_accept),nensemble); end;
meanu2 = diag(u*u'/n); 
fprintf(1,'\n mean(u^2) =%9.4g  %9.4g  %9.4g ',meanu2);
if max((meanu2-1).^2) > 0.04;  %((
fprintf(' <### WARNING ###: mean(u^2) not close to unity')
end; %))
end; %)))

