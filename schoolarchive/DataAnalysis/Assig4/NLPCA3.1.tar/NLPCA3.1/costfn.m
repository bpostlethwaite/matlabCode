function [J] = costfn(W);
% function [J] = costfn(W);
% cost function

global  iprint isave linear nensemble testfrac segmentlength ...
  overfit_tol earlystop_tol xscaling penalty maxiter initRand ...
  initwt_radius options  n l m nbottle iter Jscale xmean xstd...
  ntrain xtrain utrain xitrain ntest xtest utest xitest MSEx ...
  ens_accept ens_MSEx ens_W ens_utrain ens_xitrain ens_utest ens_xitest

[utrain] = mapu(xtrain,W); % forward map from x to u
[xitrain,J,junk] = invmapx(utrain,xtrain,W); % inverse map from u to xi
iter = iter+1;






