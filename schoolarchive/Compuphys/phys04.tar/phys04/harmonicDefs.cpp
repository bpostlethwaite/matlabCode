/*  harmonicDefs.cpp

    Ben Postlethwaite
    Physics 410 

    *** Function Definitions  ***

 */

// Function Declarations

#include <cmath>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include "harmonicHeaders.h" // Include protypes

using namespace  std;

void getdata (double& initial_x, double& initial_v, double& h)
{
 cout << "Initial position = ";
 cin >> initial_x;
 cout << "Initial speed = ";
 cin >> initial_v;
 cout << "step size = ";
 cin >> h;
}  // end of function getdata

//   this function sets up the derivatives for this special case
void derivatives(double t, double *y, double *dydt)
{
  dydt[0]=y[1];    // derivative of x
  dydt[1]=-y[0]; // derivative of v
} // end of function derivatives

//    function to write out the final results
void fsend(ostream & os,double t, double *y, double h, double E0)
{
  os << setiosflags(ios::showpoint | ios::uppercase);
  os << setw(15) << setprecision(8) << t;
  os << setw(15) << setprecision(8) << y[0];
  os << setw(15) << setprecision(8) << y[1];
  os << setw(15) << setprecision(8) << h;
  os << setw(15) << setprecision(8) <<
    0.5*y[0]*y[0]+0.5*y[1]*y[1]-E0 << endl; // deviations from initial energy
}  // end of function fsend


void RK2(double *y, double *dydt, int n, double x, double h,
        double *yout, void (*derivs)(double, double *, double *))
{
	int i;
	double xh;
	double *dyt, *yt;
	// reserve memory
	dyt =  new double [n];
	yt =  new double [n];
	xh = x+h/2.0;
	for (i=0; i < n; i++) {
		yt[i] = y[i] + h/2.0*dydt[i];
	}

	// Compute y(t) + 1/2h = y(t) +
	(*derivs)(xh,yt,dyt);

	// Get k2

	for (i=0; i < n; i++){
		yout[i] = y[i] + h*dyt[i];
	}
	  delete [] dyt;
	  delete [] yt;

}

/*   This function upgrades a function y (input as a pointer)
     and returns the result yout, also as a pointer. Note that
     these variables are declared as arrays.  It also receives as
     input the starting value for the derivatives in the pointer
     dydx. It receives also the variable n which represents the
     number of differential equations, the step size h and
     the initial value of x. It receives also the name of the
     function *derivs where the given derivative is computed
*/

void RK4(double *y, double *dydx, int n, double x, double h,
                   double *yout, void (*derivs)(double, double *, double *))
{
  int i;
  double      xh,hh,h6;
  double *dym, *dyt, *yt;
  //   allocate space for local vectors
  dym = new double [n];
  dyt =  new double [n];
  yt =  new double [n];
  hh = h*0.5;
  h6 = h/6.;
  xh = x+hh;
  for (i = 0; i < n; i++) {
    yt[i] = y[i]+hh*dydx[i];
  }
  (*derivs)(xh,yt,dyt);     // computation of k2, eq. 3.60
  for (i = 0; i < n; i++) {
    yt[i] = y[i]+hh*dyt[i];
  }
  (*derivs)(xh,yt,dym); //  computation of k3, eq. 3.61
  for (i=0; i < n; i++) {
    yt[i] = y[i]+h*dym[i];
    dym[i] += dyt[i];
  }
  (*derivs)(x+h,yt,dyt);    // computation of k4, eq. 3.62
  //      now we upgrade y in the array yout
  for (i = 0; i < n; i++){
    yout[i] = y[i]+h6*(dydx[i]+dyt[i]+2.0*dym[i]);
  }
  delete []dym;
  delete [] dyt;
  delete [] yt;
}       //  end of function Runge-kutta 4
