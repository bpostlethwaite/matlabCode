/* harmonicHeaders.h
   Ben Postlethwaite

   ***  Headers  ***
*/

#ifndef harmonic_H_
#define hamonic_H_

#include <iosfwd>
using std::ostream; 

// function prototypes
void derivatives(double, double *, double *);
void getdata ( double&, double&, double&);
void fsend(ostream&, double, double *, double, double);
void RK2(double *, double *, int, double, double,
        double *, void (*)(double, double *, double *));
void RK4(double *, double *, int, double, double,
                   double *, void (*)(double, double *, double *));
// Const Variables


#endif
