/*    harmonicMain.cpp

      Ben Postlethwaite
      Physics 410 Assignment 4

      *** Main ***
      */
#include <cmath>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include "harmonicHeaders.h"


using std::ofstream;
using std::cerr;
using std::endl;

// fsend file as global variable



int main()
{
  //  declarations of variables
  double *yR2,*yR4, *dydt2, *dydt4, *youtR2, *youtR4, t, h, tmax, E_R2, E_R4;
  double initial_x, initial_v, m = 0.1, k = 6.4, mk, PI = 3.14159265358;
  int i, numSteps, n;

  // Create ofstream object outdata, open file ready for writing.
  ofstream outdata1, outdata2; // outdata is like cin
  const char * fn1 = "phys04Adata.txt";
  const char * fn2 = "phys04Bdata.txt";
  outdata1.open(fn1);
  outdata2.open(fn2);
  if( !outdata1 || !outdata2) { // file couldn't be opened
    cerr << "Error: file could not be opened" << endl;
    exit(1);
  }


  // number of Differential equations
  n = 2;
  //  allocate space in memory for the arrays containing the derivatives
  dydt2 = new double[n];	dydt4 = new double[n];
  yR2 = new double[n];  	yR4 = new double[n];
  youtR2 = new double[n];   youtR4 = new double[n];

  // read in the initial position, velocity and step size
  getdata (initial_x, initial_v, h);

  //  setting initial values, step size and max time tmax
  // Non Dimensionalize v and t
  mk = sqrt(m/k);
  tmax = (12 * PI) * mk;     // NON dimensionalize tmax
  initial_v *= sqrt(m/k);
  numSteps = tmax/h;
  yR2[0] =  yR4[0]   = initial_x;      // initial position
  yR2[1] = yR4[1] = initial_v;         // initial velocity
  t=0.0;                               // initial time
  E_R2 = 0.5*yR2[0]*yR2[0]+0.5*yR2[1]*yR2[1];       // the initial total energy
  E_R4 = 0.5*yR4[0]*yR4[0]+0.5*yR4[1]*yR4[1];

  // now we start solving the differential equations using the RK4 method
  while (t <= tmax){
    derivatives(t, yR2, dydt2);   // initial derivatives
    derivatives(t, yR4, dydt4);   // initial derivatives
    RK2(yR2,dydt2,n,t,h,youtR2,derivatives);
    RK4(yR4, dydt4, n, t, h, youtR4, derivatives);
    for (i = 0; i < n; i++) {
      yR2[i] = youtR2[i];
      yR4[i] = youtR4[i];
    }
    t += h*mk; // NON dimensionalize tmax
    fsend(outdata1,t, yR2, h, E_R2);   // write to file
    fsend(outdata2,t, yR4, h,  E_R4);   // write to file
  }

  delete [] yR2; delete [] dydt2; delete [] dydt4; 
  delete [] youtR2; delete [] yR4; delete [] youtR4;
  
  outdata1.close();  // close fsend file
  outdata2.close();
  
  return 0;
}   //  End of main function


