function [alphaValue] = alphaGen(G,WtW,D,mref,n,tol)

% This super long string gets a range value for matrix W, so we can set the
% alpha range correctly (This is because I build them differently than Eldad).
% So I need to switch the ranges automatically depending on the W that is
% fed into the function. 

c =round(abs( full(log10(sum(sum(sum(WtW)))))));
h = waitbar(0,'Optimizing alpha value, please wait');

% Set up sigma two methods
% sigmaD = std(D); % Get standard deviation of data
% This next

 sigmaD = 0.1*max(D);
SigN = sigmaD^2*n^2;
% Set up alpha
alpha = logspace(-1,5+c,800);
count = 2;
a = round(length(alpha)/2);
MInv = (G*G' + alpha(a).*(WtW))\(G*D + alpha(a).*(WtW)*mref);
A = (G'*MInv-D)'*(G'*MInv-D);
while  A > SigN + SigN*tol || A < SigN - SigN*tol
    if A > SigN + SigN*tol
        a = round(a - a/count) + 1;
    else
        a =  round(a + a/count) - 1;
    end
    count = count +1;
    MInv = (G*G' + alpha(a).*(WtW))\(G*D + alpha(a).*(WtW)*mref);
    A = (G'*MInv-D)'*(G'*MInv-D); 
    waitbar(count/(0.5*length(alpha)))
end
alphaValue = alpha(a);
close(h)

%% Get nice misfit curve
% h = waitbar(0,'Generating an alpha value, please wait');
% Wmisfit = zeros(1,length(alpha));
% for ii = 1:length(alpha)
%     MInv = (G*G' + alpha(ii).*(WtW))\(G*D + alpha(ii).*(WtW)*mref);
%     %misfit(ii)=(G'*MInv-D)'*(G'*MInv-D);
%         Wmisfit(ii) = ((W*MInv)'*(W*MInv));
%     waitbar(ii/length(alpha))
% end
% 
% close(h)

end