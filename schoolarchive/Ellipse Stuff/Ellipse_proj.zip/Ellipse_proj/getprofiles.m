function [prof_lat prof_lon] = getprofiles(lat0,lon0,mainellipse,minorellipse,offset,az1,az2,planet,units,num_pts,rng)



for ii = 1:length(az2(:,1))
[elat,elon] = ellipse1(lat0,lon0,mainellipse,offset,az1(ii,:),planet,units,num_pts(1)); %an arc of Large ellipse lat and lon 
[elat2,elon2] = ellipse1(lat0,lon0,minorellipse,offset,az2(ii,:),planet,units,num_pts(2)); % an arc Small ellipse lat and lon

Pt1 = [elat,elon]; % Pt1 is an ellipse vector for the arc computed above
Pt2 = [elat2(4).*ones(length(elat),1),elon2(4).*ones(length(elat),1)]; %Pt2 is the middle lat and lon coord of the arc computed
% for the minor ellipse, copied over the same number of columns as the
% major ellipse arc
[dist,AZ] = distance(Pt1,Pt2,planet); % This computes the distance between the two arcs as well as the azimuthal angle
% between points on each arc 


[prof_lat(:,ii),prof_lon(:,ii)] = track1(elat(dist==min(dist)),elon(dist==min(dist)),AZ(dist==min(dist)),rng); %This finds the 
% lon and lat coord on the mainellipse arc which minimizes the distance
% between the two arcs, ie the norm, it uses the angle between this min
% distance arc to arc lon lat coords to draw (continue) a great circle line
% It stores the lat and lon coords.

end

end